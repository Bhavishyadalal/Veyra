import { test, expect } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";
test.beforeEach(async ({ page }) => {
  await page.addInitScript(() => sessionStorage.setItem("veyra-v2-intro", "1"));
});
test("production page loads local assets without runtime errors", async ({
  page,
}) => {
  const errors = [];
  const failed = [];
  page.on("pageerror", (e) => errors.push(e.message));
  page.on("response", (r) => {
    if (r.url().startsWith("http://127.0.0.1") && r.status() >= 400)
      failed.push(r.url());
  });
  await page.goto("/");
  await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
  await page.locator("#inside").scrollIntoViewIfNeeded();
  await expect(page.getByRole("tabpanel")).toBeVisible();
  await page.locator(".signal-section").scrollIntoViewIfNeeded();
  await expect(page.locator(".flux-lines-canvas")).toBeAttached();
  await expect(
    page.getByRole("button", { name: "Open the hidden signal", exact: true }),
  ).toBeVisible();
  expect(errors).toEqual([]);
  expect(failed).toEqual([]);
});
test("four phone screens work, including keyboard tab navigation", async ({
  page,
}) => {
  await page.goto("/");
  await page.getByRole("tab", { name: "Home", exact: true }).click();
  await expect(page.getByRole("tabpanel")).toContainText("Listen Now");
  await page
    .getByRole("tab", { name: "Home", exact: true })
    .press("ArrowRight");
  await expect(
    page.getByRole("tab", { name: "Player", exact: true }),
  ).toHaveAttribute("aria-selected", "true");
  await expect(page.getByRole("tabpanel")).toContainText("Cue the words");
  await page
    .getByRole("tab", { name: "Player", exact: true })
    .press("ArrowRight");
  await expect(page.getByRole("tabpanel")).toContainText(
    "Somewhere beyond the noise.",
  );
  await page.getByRole("tab", { name: "Lyrics", exact: true }).press("End");
  await expect(page.getByRole("tabpanel")).toContainText("Local Music");
});
test("demo mood, likes, timer and next track respond", async ({ page }) => {
  await page.goto("/");
  await page.getByRole("button", { name: /Daydream/ }).click();
  await expect(page.getByRole("tabpanel")).toContainText("Bloom");
  await page
    .getByRole("button", { name: "Like demo track", exact: true })
    .click();
  await expect(
    page.getByRole("button", { name: "Unlike demo track", exact: true }),
  ).toHaveAttribute("aria-pressed", "true");
  await page
    .getByRole("button", { name: "Play visual demo", exact: true })
    .click();
  await expect(
    page.getByRole("button", { name: "Pause visual demo", exact: true }),
  ).toBeVisible();
  await expect
    .poll(() => page.locator("#demo-position").inputValue())
    .not.toBe("0");
  await page
    .getByRole("button", { name: "Pause visual demo", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Next demo track", exact: true })
    .click();
  await expect(page.getByRole("tabpanel")).toContainText("Orbit");
});
test("hidden signal is modal, keyboard dismissible and restores focus", async ({
  page,
}) => {
  await page.goto("/");
  const trigger = page.getByRole("button", {
    name: "Open the hidden frequency",
    exact: true,
  });
  await trigger.click();
  await expect(page.getByRole("dialog")).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Close hidden signal", exact: true }),
  ).toBeFocused();
  await page.keyboard.press("Tab");
  expect(
    await page.evaluate(() =>
      document.querySelector("dialog").contains(document.activeElement),
    ),
  ).toBe(true);
  await page.keyboard.press("Escape");
  await expect(page.getByRole("dialog")).toHaveCount(0);
  await expect(trigger).toBeFocused();
});
test("motion preference persists and disables decorative effects", async ({
  page,
}) => {
  await page.goto("/");
  await page.getByRole("button", { name: /Motion on/ }).click();
  await expect(page.locator("html")).toHaveAttribute("data-motion", "reduced");
  await expect(page.locator(".story-stack")).toHaveClass(/static-stack/);
  await page.reload();
  await expect(page.locator("html")).toHaveAttribute("data-motion", "reduced");
  await page.locator(".signal-section").scrollIntoViewIfNeeded();
  await expect(page.locator(".flux-lines-canvas")).toHaveCount(0);
});
test("OS reduced motion works without requiring a stored preference", async ({
  page,
}) => {
  await page.emulateMedia({ reducedMotion: "reduce" });
  await page.goto("/");
  await expect(page.locator("html")).toHaveAttribute("data-motion", "reduced");
  await expect(page.locator(".opening")).toHaveCount(0);
  await expect(page.locator(".story-stack")).toHaveClass(/static-stack/);
});
test("viewport widths do not create horizontal scrolling", async ({ page }) => {
  await page.goto("/");
  for (const width of [320, 360, 390, 768, 1024, 1440, 1920]) {
    await page.setViewportSize({ width, height: 900 });
    await expect
      .poll(() =>
        page.evaluate(
          () =>
            document.documentElement.scrollWidth <=
            document.documentElement.clientWidth + 1,
        ),
      )
      .toBe(true);
  }
});
test("scroll stack retains every chapter and real navigation targets", async ({
  page,
}) => {
  await page.goto("/");
  await expect(page.locator(".scroll-stack-card")).toHaveCount(3);
  for (const card of await page.locator(".chapter").all()) {
    await card.scrollIntoViewIfNeeded();
    await expect(card.locator("h3")).toBeVisible();
  }
  const ids = await page
    .locator("[id]")
    .evaluateAll((nodes) => nodes.map((n) => n.id));
  expect(new Set(ids).size).toBe(ids.length);
  await page
    .getByRole("link", { name: "Get the Android app", exact: true })
    .click();
  await expect(page).toHaveURL(/#download$/);
  await expect(
    page.getByRole("link", { name: "Find Android releases", exact: true }),
  ).toBeInViewport();
});
test("FAQ and external download links are honest and actionable", async ({
  page,
}) => {
  await page.goto("/");
  await page
    .locator("summary")
    .filter({ hasText: "Where can I download" })
    .click();
  await expect(page.locator("details[open]")).toContainText(
    "not an installable APK",
  );
  await expect(
    page.getByRole("link", { name: "Find Android releases", exact: true }),
  ).toHaveAttribute("href", "https://github.com/Bhavishyadalal/Veyra/releases");
  await expect(
    page.getByRole("link", { name: "Android Studio source ZIP", exact: true }),
  ).toHaveAttribute("href", /\.zip$/);
});
test("mobile navigation opens, closes and restores keyboard focus", async ({
  page,
}, testInfo) => {
  test.skip(
    !testInfo.project.name.startsWith("mobile"),
    "Mobile menu is not present on desktop.",
  );
  await page.goto("/");
  const toggle = page.getByRole("button", { name: "Open menu", exact: true });
  await toggle.click();
  await expect(page.getByRole("navigation")).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(toggle).toBeFocused();
  await toggle.click();
  await page.getByRole("link", { name: "Inside Veyra", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Open menu", exact: true }),
  ).toHaveAttribute("aria-expanded", "false");
  await expect(page).toHaveURL(/#inside$/);
});
test("landing and every preview screen pass automated accessibility checks", async ({
  page,
}) => {
  await page.goto("/");
  await page.emulateMedia({ reducedMotion: "reduce" });
  await expect(page.locator("html")).toHaveAttribute("data-motion", "reduced");
  for (const tab of ["Home", "Player", "Lyrics", "Library"]) {
    await page.getByRole("tab", { name: tab, exact: true }).click();
    await expect(
      page.getByRole("tab", { name: tab, exact: true }),
    ).toHaveAttribute("aria-selected", "true");
    await page.waitForTimeout(300);
    const results = await new AxeBuilder({ page }).analyze();
    expect(
      results.violations.map((v) => ({
        id: v.id,
        nodes: v.nodes.map((n) => n.target),
      })),
    ).toEqual([]);
  }
  await page
    .getByRole("button", { name: "Open the hidden signal", exact: true })
    .click();
  const result = await new AxeBuilder({ page }).analyze();
  expect(result.violations).toEqual([]);
});
test("supporting pages build and pass accessibility checks", async ({
  page,
}) => {
  for (const name of ["privacy", "credits"]) {
    await page.goto(`/${name}.html`);
    await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
    expect((await new AxeBuilder({ page }).analyze()).violations).toEqual([]);
  }
});
test("no-JavaScript page has a useful fallback", async ({ browser }) => {
  const context = await browser.newContext({ javaScriptEnabled: false });
  const p = await context.newPage();
  await p.goto("http://127.0.0.1:4173");
  await expect(p.locator(".noscript-notice")).toBeVisible();
  await expect(
    p.getByRole("link", { name: "Find Veyra releases" }),
  ).toHaveAttribute("href", /releases$/);
  await context.close();
});

test("optional WebGL effects fail gracefully without breaking controls", async ({
  page,
}) => {
  await page.addInitScript(() => {
    const original = HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext = function (type, ...args) {
      if (type === "webgl" || type === "webgl2") return null;
      return original.call(this, type, ...args);
    };
  });
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("/");
  await page
    .getByRole("button", { name: "Enter the experience", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Open the hidden signal", exact: true })
    .click();
  await expect(page.getByRole("dialog")).toBeVisible();
  await page.keyboard.press("Escape");
  await page.getByRole("tab", { name: "Library", exact: true }).click();
  await expect(page.getByRole("tabpanel")).toContainText("Downloads");
  expect(errors).toEqual([]);
});
