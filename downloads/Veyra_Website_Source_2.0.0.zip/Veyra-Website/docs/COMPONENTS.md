# Requested components and artwork provenance

React Bits official source: https://github.com/DavidHDev/react-bits

Pinned commit: `d965399df489c7b8da3874e07d716c0d98ab39fd`

Included FluxLines, SpecularButton and ScrollStack JS/CSS files were copied byte-for-byte from the `files[].content` fields of the official `public/r/<Name>-JS-CSS.json` registry definitions. These match the requested shadcn component variants. No runtime dependencies were required by those registry entries.

The direct registry requests to reactbits.dev returned HTTP 403 in this cloud environment. `npx shadcn@latest add` using the local official JSON files then failed fetching ui.shadcn.com color metadata. Rather than changing network policy or recreating lookalikes, the exact source files were installed from the allowed official GitHub checkout. Keep `docs/licenses/React-Bits.txt` with the integrated components.

| Installed file | SHA-256 |
| --- | --- |
| `src/components/FluxLines.css` | `fd0d908ca6c047e6bd0f8bba2e13fe037ecca0b6e894b3f0612777c75f68950d` |
| `src/components/FluxLines.jsx` | `f29fdc61ea2a0684432a2d6ccccd2ef4cf7f10857046daab5e523568e5d9ce07` |
| `src/components/ScrollStack.css` | `64b2bf8c66a1958e0405ed6b885086562e635c22f0f1f79950806661d5470013` |
| `src/components/ScrollStack.jsx` | `e73d47bae2967bf5f4051a8600387ff460dc381a2c8c571c76d28f42aa970292` |
| `src/components/SpecularButton.css` | `af7cad9998bd6102a21fd05da11890ca05c061f9d5e6c96f540fb744684442a9` |
| `src/components/SpecularButton.jsx` | `943e8535a527563577d07da8f21b680bc70a1866a75d14bbbd396fb92d95cfa6` |

## Motion

Installed from npm: `motion` 14.3.0. Imports come from `motion/react`. `npx motion-ai` 14.2.0 was run in project scope for Codex. Its development-only agent/MCP setup is excluded from the website ZIP; no Motion+ account or service is required to preview or deploy the site.

## Artwork

`public/images/chrome-wave.webp` and `vinyl-portal.webp` were generated for this showcase with OpenAI image generation on 18 October 2026, then encoded as WebP. Prompts requested original abstract liquid-chrome sound sculpture and a surreal black vinyl portal, with black negative space, silver/violet lighting and no text, app UI, trademarked hardware or logos. The readable buttons and text are live HTML/CSS.

`public/artwork/*.svg` are original illustrative demo covers, with fictional track names. The supplied Veyra icon is copied from the Android project. The four user-shared app screenshots informed the phone illustration; commercial cover images and third-party lyric text from those screenshots were not copied into website assets.

## Fonts

Anton was downloaded from the official google/fonts `ofl/anton` directory, with its OFL file. Manrope retains its included OFL. Super Malibu uses the recorded owner authorization in `Super-Malibu-Provenance.md`.
