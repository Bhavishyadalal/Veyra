# Customizing Veyra 2.0

- **Links:** `src/config.js` holds the actual Android version, repository, releases and source ZIP. Release availability is determined by GitHub, so add an APK-specific link only after publishing a real artifact.
- **Typography:** Anton is used for oversized headings, Manrope for UI/body, and Super Malibu only for the wordmark. All files are local; retain their notices.
- **Art direction:** `public/images/` contains the two generated WebP artworks. Keep filenames or update references in `src/main.jsx`. Both are decorative and have empty alt text. New informational images need meaningful alternatives.
- **Moods:** the `moods` array in `src/main.jsx` controls accent, artwork, demo track and original lyric text. Preview audio is intentionally absent.
- **Screens:** the phone preview is a web illustration inspired by the supplied app screenshots. To use real app captures instead, add owned images and label them as actual captures only when accurate.
- **ScrollStack:** native window scrolling is enabled; smooth-wheel interception and snap are disabled. Manual/system reduced motion flattens the chapters into normal flow. Mobile cards fit the narrow layout without rotating or blurring content.
- **Motion:** the switch saves `veyra-site-motion`; `veyra-v2-intro` is a per-tab session flag. The system reduced-motion preference always takes priority. Do not force motion back on against that preference.
- **Hidden scene:** `Portal` uses native dialog focus trapping, Escape dismissal and focus restoration. Preserve those behaviors when changing its layout.
- **Colors/layout:** `src/styles/v2.css` holds responsive rules, with mobile layouts at 760px and small-phone adjustments below 360px.
- **Deployment:** keep `privacy.html` and `credits.html` as build inputs and update notices if you add analytics, embedded services, forms or remote fonts.
- **Component updates:** retain upstream React Bits notices and record the updated source commit and hashes in `COMPONENTS.md`.

Do not ship node_modules, dist, credentials, editor/MCP account configuration or build reports in a source archive.
