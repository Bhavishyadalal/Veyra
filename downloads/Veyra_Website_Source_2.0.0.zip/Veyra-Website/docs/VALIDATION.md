# Veyra website 2.0.0 — delivery validation

18 October 2026. This report concerns the standalone website, not the Android build.

## Production and browser checks

- Production build: passed with Node 24.19.0, npm 11.9.0 and Vite 8.3.4.
- Playwright: **27 passed, 1 skipped, 0 failed**, across desktop Chromium and Pixel 7 mobile emulation. The skipped case is the mobile-only menu test in the desktop project.
- Browser: system Chromium 154.0.8037.57. Desktop 1440×1000; mobile 390×844; responsive horizontal-overflow checks at 320, 360, 390, 768, 1024, 1440 and 1920px.
- Verified local assets and runtime startup; all four phone screens; keyboard tabs; mood changes; visual playback/seek/likes/next track; native modal dismissal and focus restoration; FAQ; actual project/download links; persistent manual reduced motion; live system reduced-motion preference; no-JavaScript fallback; mobile menu; and optional WebGL failure behavior.
- Automated axe checks found no violations in the four phone states, the hidden-scene dialog, and privacy/credits pages in both browser projects.
- Original chrome/portal images are local WebP assets totaling about 192KB. FluxLines is a separate lazy-loaded chunk and only mounts near its section in normal motion mode. Pixel ratio is capped at 1 for that effect. Its upstream visibility handler stops work offscreen/when the tab is hidden.
- Main JavaScript: approximately 134KB gzip in this build. The phone preview does not fetch music or remote artwork.
- Manual captures reviewed: desktop/mobile opening, discovery chapter, interactive phone and hidden scene. Preview images are in this directory.

## Limits

These are Chromium checks with mobile emulation, not physical-phone or Safari/Firefox certification. The Windows launcher is included and its commands are documented; this Linux environment cannot execute a native Windows Command Prompt session. Automated accessibility checks are useful evidence, not a complete accessibility audit. No APK or Android build was generated, and no website deployment was performed.

## Dependency/component installation

Motion, React and the build/test packages installed from npm. Motion AI Kit completed in project scope. The React Bits registry returned HTTP 403, and shadcn's local-registry attempt failed fetching its color metadata. All three requested component variants were installed from exact official GitHub registry file content; source commit and SHA-256 hashes are recorded in COMPONENTS.md.

## Archive verification

Fresh extraction: `npm ci --include=dev --no-fund --no-audit` passed (32 packages installed), followed by a successful production build. The development server also passed a real browser smoke test: mood change, phone render, modal open and Escape dismissal, with no runtime errors. The final archive excludes node_modules, dist, reports, secrets and development agent/MCP configuration. A SHA-256 sidecar accompanies the ZIP.
