package app.veyra.music.ui.screens

import android.content.Context
import android.content.Intent
import app.veyra.music.ui.icons.SettingsIcons
import androidx.compose.foundation.border
import androidx.compose.foundation.selection.selectable
import android.media.AudioFormat
import android.media.audiofx.AudioEffect
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.tween
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.ScrollState
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Notes
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.rounded.Animation
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.BlurOff
import androidx.compose.material.icons.rounded.BlurOn
import androidx.compose.material.icons.rounded.Brightness4
import androidx.compose.material.icons.rounded.Cached
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.FilterAlt
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.Gradient
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.LocalOffer
import androidx.compose.material.icons.rounded.MusicOff
import androidx.compose.material.icons.rounded.MotionPhotosOff
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.Draw
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlaylistPlay
import androidx.compose.material.icons.rounded.SignalCellularAlt
import androidx.compose.material.icons.rounded.SmartDisplay
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.SurroundSound
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.WebAssetOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Waves
import androidx.compose.material.icons.rounded.Wifi
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import app.veyra.music.data.lyrics.translationLanguageName
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import app.veyra.music.ui.components.veyraSwitchColors
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.viewinterop.AndroidView
import app.veyra.music.AppIcon
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withLink
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.SingletonImageLoader
import coil3.compose.AsyncImage
import app.veyra.music.ui.components.isGlassSupported
import app.veyra.music.ui.components.languageDisplayNameRes
import app.veyra.music.ui.components.MessageState
import app.veyra.music.ui.components.SearchField
import app.veyra.music.ui.components.thumbnailBorder
import app.veyra.music.ui.icons.VeyraIcons
import app.veyra.music.ui.performance.resolvePerformanceRefreshRate
import app.veyra.music.ui.performance.supportedPerformanceRefreshRates
import app.veyra.music.data.model.Account
import app.veyra.music.data.LocalMediaRepository
import app.veyra.music.data.NerdStats
import app.veyra.music.data.scrobbling.LastFM
import app.veyra.music.data.listentogether.ListenTogether
import app.veyra.music.data.settings.AppSettings
import app.veyra.music.data.settings.OutputPcmMode
import app.veyra.music.playback.AudioOutputStatus
import app.veyra.music.data.settings.AutomixPerformanceMode
import app.veyra.music.R
import app.veyra.music.data.sources.DeviceCodecs
import app.veyra.music.data.settings.AudioQuality
import app.veyra.music.data.settings.DownloadQuality
import app.veyra.music.data.settings.ThemeMode
import app.veyra.music.data.stats.Backup
import app.veyra.music.playback.AudioCache
import app.veyra.music.ui.player.fullBleedArtworkAvailable
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import java.util.Locale

/**
 * Grouped settings, in the shape phones have taught people to expect: inset
 * cards of rows, a leading glyph per row, the current value on the right, and a
 * plain-language footer under any group whose effect isn't obvious from its
 * title. Anything with more than two choices opens a sheet rather than pushing
 * a row of chips into the layout.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    /** The window's width, for the gates that depend on it. */
    windowWidth: Dp,
    signedIn: Boolean,
    account: Account?,
    onSignIn: () -> Unit,
    onSignOut: () -> Unit,
    onAccountScrobbling: () -> Unit,
    onEqualizer: () -> Unit,
    onOpenReplay: () -> Unit,
    onLyricsSources: () -> Unit,
    onTranslationLanguage: () -> Unit,
    onSources: () -> Unit,
    onListenTogether: () -> Unit,
    onSpotifyCanvasAuth: () -> Unit,
    onAppLanguage: () -> Unit,
    onEditSignatureApi: () -> Unit,
    contentPadding: PaddingValues,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current

    val wifiQuality by AppSettings.audioQualityWifi.collectAsStateWithLifecycle()
    val cellularQuality by AppSettings.audioQualityCellular.collectAsStateWithLifecycle()
    val metered by AppSettings.meteredConnection.collectAsStateWithLifecycle()
    val crossfade by AppSettings.crossfadeSeconds.collectAsStateWithLifecycle()
    val smartFade by AppSettings.smartFadeEnabled.collectAsStateWithLifecycle()
    val automixPerformance by AppSettings.automixPerformanceMode.collectAsStateWithLifecycle()
    val skipSilence by AppSettings.skipSilence.collectAsStateWithLifecycle()
    val dolbyAtmos by AppSettings.dolbyAtmos.collectAsStateWithLifecycle()
    // A property of the hardware, so it is read once rather than remembered
    // against a key that can never change — see [DeviceCodecs.playsDolbyAtmos],
    // which caches the codec-list walk for the life of the process.
    val dolbyAtmosSupported = DeviceCodecs.playsDolbyAtmos
    val spatialAudio by AppSettings.spatialAudio.collectAsStateWithLifecycle()
    val nerdStats by AppSettings.showNerdStats.collectAsStateWithLifecycle()
    val reduceAnimation by AppSettings.reduceAnimation.collectAsStateWithLifecycle()
    val reduceDynamicBlur by AppSettings.reduceDynamicBlur.collectAsStateWithLifecycle()
    val liquidGlass by AppSettings.liquidGlass.collectAsStateWithLifecycle()
    val liquidGlassSupported = isGlassSupported()
    val lyricsBlur by AppSettings.lyricsBlur.collectAsStateWithLifecycle()
    val animatedCanvas by AppSettings.animatedCanvas.collectAsStateWithLifecycle()
    val canvasOverCellular by AppSettings.canvasOverCellular.collectAsStateWithLifecycle()
    val signatureApiEnabled by AppSettings.signatureApiEnabled.collectAsStateWithLifecycle()
    val signatureApiUrl by AppSettings.signatureApiUrl.collectAsStateWithLifecycle()
    val fullBleedArtwork by AppSettings.fullBleedArtwork.collectAsStateWithLifecycle()
    val legacyMeshGradient by AppSettings.legacyMeshGradient.collectAsStateWithLifecycle()
    val syncedLyrics by AppSettings.syncedLyrics.collectAsStateWithLifecycle()
    val lyricsSources by AppSettings.lyricsSources.collectAsStateWithLifecycle()
    val translationLanguage by AppSettings.translationLanguage.collectAsStateWithLifecycle()
    val theme by AppSettings.themeMode.collectAsStateWithLifecycle()
    val sessionId by AppSettings.audioSessionId.collectAsStateWithLifecycle()
    val outputPcmMode by AppSettings.outputPcmMode.collectAsStateWithLifecycle()
    val preferUsbDac by AppSettings.preferUsbDac.collectAsStateWithLifecycle()
    val loudnessNormalization by AppSettings.loudnessNormalization.collectAsStateWithLifecycle()
    val loudnessOffOnSpeaker by AppSettings.loudnessOffOnSpeaker.collectAsStateWithLifecycle()
    val outputStatus by AudioOutputStatus.current.collectAsStateWithLifecycle()
    val playingDolbyAtmos by remember {
        NerdStats.current.map { it?.isDolbyAtmos == true }.distinctUntilChanged()
    }.collectAsStateWithLifecycle(initialValue = NerdStats.current.value?.isDolbyAtmos == true)
    val cacheLimitBytes by AppSettings.audioCacheLimitBytes.collectAsStateWithLifecycle()
    val showCacheFolder by AppSettings.showCacheFolder.collectAsStateWithLifecycle()
    val downloadQuality by AppSettings.downloadQuality.collectAsStateWithLifecycle()
    val wifiOnlyDownloads by AppSettings.wifiOnlyDownloads.collectAsStateWithLifecycle()
    val exportDownloads by AppSettings.exportDownloads.collectAsStateWithLifecycle()
    val stopOnTaskRemoved by AppSettings.stopOnTaskRemoved.collectAsStateWithLifecycle()
    val hideVolumeBar by AppSettings.hideVolumeBar.collectAsStateWithLifecycle()
    val hideStatusBarInPlayer by AppSettings.hideStatusBarInPlayer.collectAsStateWithLifecycle()
    val hideSongStatus by AppSettings.hideSongStatus.collectAsStateWithLifecycle()
    val showQueueHistory by AppSettings.showQueueHistory.collectAsStateWithLifecycle()
    val swipeToPlayNext by AppSettings.swipeToPlayNext.collectAsStateWithLifecycle()
    val dontRepeatSuggestions by AppSettings.dontRepeatSuggestions.collectAsStateWithLifecycle()
    val preferMusicOnly by AppSettings.preferMusicOnly.collectAsStateWithLifecycle()
    val smartVersionAlignment by AppSettings.smartVersionAlignment.collectAsStateWithLifecycle()
    val filterNonMusicAudio by AppSettings.filterNonMusicAudio.collectAsStateWithLifecycle()
    val localMusicFolderUri by AppSettings.localMusicFolderUri.collectAsStateWithLifecycle()
    val highPerformanceMode by AppSettings.highPerformanceMode.collectAsStateWithLifecycle()
    val performanceRefreshRate by AppSettings.performanceRefreshRate.collectAsStateWithLifecycle()
    val currentDisplay = LocalView.current.display
    val supportedRefreshRates = remember(currentDisplay) {
        currentDisplay.supportedPerformanceRefreshRates()
    }
    val selectedPerformanceRefreshRate = remember(currentDisplay, performanceRefreshRate) {
        currentDisplay.resolvePerformanceRefreshRate(performanceRefreshRate)
    }

    LaunchedEffect(selectedPerformanceRefreshRate, performanceRefreshRate) {
        if (selectedPerformanceRefreshRate != performanceRefreshRate) {
            AppSettings.setPerformanceRefreshRate(selectedPerformanceRefreshRate)
        }
    }

    // Scrobbling states
    val lastfmEnabled by AppSettings.lastfmEnabled.collectAsStateWithLifecycle()
    val lastfmUsername by AppSettings.lastfmUsername.collectAsStateWithLifecycle()
    val lastfmSessionKey by AppSettings.lastfmSessionKey.collectAsStateWithLifecycle()
    val lastfmScrobbleEnabled by AppSettings.lastfmScrobbleEnabled.collectAsStateWithLifecycle()
    val lastfmNowPlayingEnabled by AppSettings.lastfmNowPlaying.collectAsStateWithLifecycle()
    val scrobbleMinDuration by AppSettings.scrobbleMinDuration.collectAsStateWithLifecycle()
    val scrobbleDelayPercent by AppSettings.scrobbleDelayPercent.collectAsStateWithLifecycle()
    val scrobbleDelaySeconds by AppSettings.scrobbleDelaySeconds.collectAsStateWithLifecycle()
    val listenBrainzEnabled by AppSettings.listenBrainzEnabled.collectAsStateWithLifecycle()
    val listenBrainzToken by AppSettings.listenBrainzToken.collectAsStateWithLifecycle()

    val replayGenres by AppSettings.replayGenres.collectAsStateWithLifecycle()

    // Read here so the row can say "In a party · ABC123" rather than making
    // somebody open the screen to find out whether they are still in one.
    val party by ListenTogether.state.collectAsStateWithLifecycle()

    // Search spans all categories; an empty query shows the selected category,
    // exactly as if the field weren't there.
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var picking by remember { mutableStateOf<QualityTarget?>(null) }
    var pickingDownloadQuality by remember { mutableStateOf(false) }
    var pickingAutomixPerformance by remember { mutableStateOf(false) }
    // What the last export or import did, shown on the row that did it rather
    // than as a toast: a backup is the one action here whose outcome nobody can
    // check by looking at the app afterwards. Held per direction, or an import's
    // result reports itself under the word "Export".
    var exportStatus by remember { mutableStateOf<String?>(null) }
    var importStatus by remember { mutableStateOf<String?>(null) }
    var confirmImport by remember { mutableStateOf(false) }
    var confirmClearSongCache by remember { mutableStateOf(false) }
    var showPerformanceWarning by remember { mutableStateOf(false) }
    var showPerformanceConfirmation by remember { mutableStateOf(false) }
    val backupScope = rememberCoroutineScope()

    val batterySettingsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) {
        showPerformanceConfirmation = true
    }
    val localMusicFolderPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree(),
    ) { folder ->
        if (folder == null) return@rememberLauncherForActivityResult
        runCatching {
            context.contentResolver.takePersistableUriPermission(
                folder,
                Intent.FLAG_GRANT_READ_URI_PERMISSION,
            )
        }
        AppSettings.setLocalMusicFolderUri(folder.toString())
    }

    /**
     * Both halves go through the system document picker rather than a path of
     * this app's own choosing. That is what puts the file somewhere the user can
     * actually find it — Drive, Files, a folder they already back up — and it
     * means neither direction needs a storage permission, since the grant
     * arrives with the document they picked.
     */
    val exportPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json"),
    ) { target ->
        if (target == null) return@rememberLauncherForActivityResult
        backupScope.launch {
            exportStatus = Backup.exportTo(context, target).fold(
                onSuccess = { months ->
                    context.getString(R.string.export_succeeded, context.countOfMonths(months))
                },
                onFailure = {
                    context.getString(R.string.export_failed, it.message ?: context.getString(R.string.unknown_error))
                },
            )
        }
    }
    val importPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { source ->
        if (source == null) return@rememberLauncherForActivityResult
        backupScope.launch {
            importStatus = Backup.importFrom(context, source).fold(
                onSuccess = {
                    context.getString(R.string.import_succeeded, context.countOfMonths(it.months), it.from)
                },
                onFailure = {
                    context.getString(R.string.import_failed, it.message ?: context.getString(R.string.unknown_error))
                },
            )
        }
    }
    var showListenBrainzTokenDialog by remember { mutableStateOf(false) }
    var showLastfmLoginDialog by remember { mutableStateOf(false) }
    val scrobbleScope = rememberCoroutineScope()

    val version = remember(context) {
        runCatching {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName
        }.getOrNull() ?: "1.0"
    }

    // Made fresh on every pass rather than remembered: it tallies the rows
    // that answered to the query, and that tally has to start from zero each
    // time the query changes.
    var category by rememberSaveable { mutableStateOf<SettingsCategory?>(null) }
    val searching = searchQuery.isNotBlank()
    val search = SettingsSearch(searchQuery, category)
    BackHandler(enabled = category != null || searching) {
        if (searching) searchQuery = "" else category = null
    }

    // What is left after a keystroke is a different list, and the offset the
    // last one was scrolled to means nothing in it.
    val scrollState = rememberSaveable(saver = ScrollState.Saver) { ScrollState(0) }
    var isFirstSearchComposition by remember { mutableStateOf(true) }
    LaunchedEffect(searchQuery, category) {
        if (isFirstSearchComposition && searchQuery.isEmpty()) {
            // Skip the initial composition during Activity recreation:
            // rememberSaveable already restored the scroll position.
            isFirstSearchComposition = false
        } else {
            isFirstSearchComposition = false
            scrollState.scrollTo(0)
        }
    }

    val categoryAlpha = remember { Animatable(1f) }
    LaunchedEffect(category, reduceAnimation) {
        if (reduceAnimation) {
            categoryAlpha.snapTo(1f)
        } else {
            categoryAlpha.snapTo(0f)
            categoryAlpha.animateTo(1f, tween(180))
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(contentPadding),
    ) {
        Text(
            text = stringResource(if (searching) R.string.settings else category?.title ?: R.string.settings),
            style = MaterialTheme.typography.displayLarge,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 14.dp),
        )
        SearchField(
            query = searchQuery,
            onQueryChange = { searchQuery = it },
            onSubmit = {},
            placeholder = stringResource(R.string.settings_search_hint),
            modifier = Modifier.padding(start = 20.dp, end = 20.dp, bottom = 4.dp),
        )

        if (category != null && !searching) {
            TextButton(onClick = { category = null }, modifier = Modifier.padding(horizontal = 12.dp)) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.settings))
            }
        }
        Column(
            Modifier.weight(1f).verticalScroll(scrollState)
                .graphicsLayer { alpha = categoryAlpha.value },
        ) {
            if (category == null && !searching) {
                SettingsOverview(onSelect = { category = it })
            }

            SearchableSettingsGroup(search, category = SettingsCategory.ACCOUNT, header = stringResource(R.string.account_integrations)) {
                val accountTitle = stringResource(R.string.account_integrations)
                // What the row opens is the scrobbling screen, so the services it
                // signs into are worth typing at this field even though none of
                // them is named on the row itself.
                row(accountTitle, "scrobbling", "last.fm", "listenbrainz") {
                    SettingsRow(
                        icon = SettingsIcons.Account,
                        title = accountTitle,
                        subtitle = account?.email?.takeIf { it.isNotBlank() }
                            ?: stringResource(if (signedIn) R.string.signed_in else R.string.not_signed_in),
                        onClick = onAccountScrobbling,
                    )
                }
                // Sits with the account rather than with Playback: a party is up to
                // five devices, including guests who use an installation pseudonym.
                val listenTogetherTitle = stringResource(R.string.listen_together)
                row(listenTogetherTitle, "jam", "party", "sync", "friends") {
                    SettingsRow(
                        icon = Icons.Rounded.Groups,
                        title = listenTogetherTitle,
                        subtitle = party.code?.let {
                            stringResource(R.string.listen_together_in_party, it)
                        } ?: stringResource(R.string.listen_together_subtitle),
                        badge = party.members.size.takeIf { party.inParty && it > 1 }?.toString(),
                        onClick = onListenTogether,
                    )
                }
            }

            // The row that used to sit at the top of this group was called
            // "Lossless / HQ Audio" and toggled `SourceRegistry.setModuleEnabled` —
            // it switched the *module source* on and off, not lossless. Sources
            // above lists that as the module's own row now. Lossless itself is no
            // longer a setting at all — see
            // [SourceResolver.requestForNow][app.veyra.music.data.sources.SourceResolver.requestForNow].
            SearchableSettingsGroup(search, category = SettingsCategory.SOUND, header = stringResource(R.string.audio_quality)) {
                val sourceTitle = stringResource(R.string.source)
                val sourceSubtitle = stringResource(R.string.sources_subtitle)
                row(sourceTitle, sourceSubtitle, "addon", "lossless") {
                    SettingsRow(
                        icon = Icons.Rounded.Extension,
                        title = sourceTitle,
                        subtitle = sourceSubtitle,
                        onClick = onSources,
                    )
                }
                val onWifiTitle = stringResource(R.string.on_wifi)
                row(onWifiTitle, "wi-fi", "streaming quality") {
                    SettingsRow(
                        icon = Icons.Rounded.Wifi,
                        title = onWifiTitle,
                        badge = stringResource(R.string.in_use).takeIf { metered == false },
                        value = wifiQuality.localizedLabel(),
                        onClick = { picking = QualityTarget.WIFI },
                    )
                }
                val onMobileDataTitle = stringResource(R.string.on_mobile_data)
                row(onMobileDataTitle, "cellular", "streaming quality") {
                    SettingsRow(
                        icon = SettingsIcons.Performance,
                        title = onMobileDataTitle,
                        badge = stringResource(R.string.in_use).takeIf { metered == true },
                        value = cellularQuality.localizedLabel(),
                        onClick = { picking = QualityTarget.CELLULAR },
                    )
                }
                // Sits with the quality ceilings rather than with Playback: it
                // decides which version of a track gets fetched, the same question
                // the two rows above answer, and not how one is played back.
                //
                // Greyed rather than hidden where the device can't decode E-AC-3.
                // A missing row reads as a feature the app doesn't have; a disabled
                // one with a reason under it is the difference between "Veyra
                // has no Atmos" and "this phone has no Dolby decoder", and only the
                // second is true. The stored preference is left untouched either
                // way — see [AppSettings.dolbyAtmos].
                val dolbyAtmosTitle = stringResource(R.string.dolby_atmos)
                row(dolbyAtmosTitle, "surround", "e-ac-3") {
                    SettingsRow(
                        iconPainter = painterResource(R.drawable.ic_dolby_atmos),
                        title = dolbyAtmosTitle,
                        subtitle = stringResource(
                            if (dolbyAtmosSupported) {
                                R.string.dolby_atmos_subtitle
                            } else {
                                R.string.dolby_atmos_unavailable
                            },
                        ),
                        enabled = dolbyAtmosSupported,
                        trailing = {
                            Switch(
                                checked = dolbyAtmos && dolbyAtmosSupported,
                                onCheckedChange = AppSettings::setDolbyAtmos,
                                enabled = dolbyAtmosSupported,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setDolbyAtmos(!dolbyAtmos) },
                    )
                }
            }

            // Its own group rather than rows bolted onto the two above, because a
            // download is not a third kind of connection. The ceilings answer "what
            // does this minute cost"; these answer "what am I keeping, and when may
            // it be fetched" — and those two questions only make sense read
            // together, which is what puts them side by side here.
            SearchableSettingsGroup(search, category = SettingsCategory.LIBRARY, header = stringResource(R.string.downloads)) {
                val downloadQualityTitle = stringResource(R.string.download_quality)
                row(downloadQualityTitle, "offline", "lossless") {
                    SettingsRow(
                        icon = Icons.Rounded.Download,
                        title = downloadQualityTitle,
                        subtitle = stringResource(R.string.download_quality_subtitle, downloadQuality.perTrack),
                        value = downloadQuality.localizedLabel(),
                        onClick = { pickingDownloadQuality = true },
                    )
                }
                // Reads as part of Download quality above it, not as a setting
                // of its own — same treatment as Play animated cover over
                // cellular gets under Animated cover art.
                val downloadWifiOnlyTitle = stringResource(R.string.download_wifi_only)
                row(downloadWifiOnlyTitle, "wi-fi", "cellular", divided = false) {
                    SettingsSubRow(
                        title = downloadWifiOnlyTitle,
                        checked = wifiOnlyDownloads,
                        onCheckedChange = AppSettings::setWifiOnlyDownloads,
                        badge = stringResource(R.string.blocking).takeIf { wifiOnlyDownloads && metered == true },
                    )
                }
                val exportDownloadsTitle = stringResource(R.string.export_compatible_downloads)
                row(exportDownloadsTitle, "music folder", divided = false) {
                    SettingsSubRow(
                        title = exportDownloadsTitle,
                        checked = exportDownloads,
                        onCheckedChange = AppSettings::setExportDownloads,
                        subtitle = "Music/Veyra".takeIf { exportDownloads },
                    )
                }
            }

            SearchableSettingsGroup(search, category = SettingsCategory.SOUND, header = stringResource(R.string.playback)) {
                val preferMusicOnlyTitle = stringResource(R.string.prefer_music_only)
                row(preferMusicOnlyTitle, "video", "audio", "music video") {
                    SettingsRow(
                        icon = Icons.Rounded.SmartDisplay,
                        title = preferMusicOnlyTitle,
                        subtitle = stringResource(R.string.prefer_music_only_subtitle),
                        trailing = {
                            Switch(
                                checked = preferMusicOnly,
                                onCheckedChange = AppSettings::setPreferMusicOnly,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setPreferMusicOnly(!preferMusicOnly) },
                    )
                }
                val outputPrecisionTitle = stringResource(R.string.output_precision)
                row(outputPrecisionTitle, "pcm", "bit depth", "sample rate", "dac") {
                    SettingsRow(
                        icon = Icons.Rounded.GraphicEq,
                        title = outputPrecisionTitle,
                        subtitle = buildString {
                            append(outputStatus.sink)
                            append(" · ")
                            append(outputStatus.deviceName)
                            (outputStatus.actualSampleRateHz ?: outputStatus.sampleRatesHz.firstOrNull())
                                ?.let { append(" · ${it / 1000.0} kHz") }
                            append(" · ")
                            append(AudioOutputStatus.encodingLabel(outputStatus))
                        },
                    )
                    SegmentedControl(
                        options = OutputPcmMode.entries.map(OutputPcmMode::label),
                        selectedIndex = OutputPcmMode.entries.indexOf(outputPcmMode),
                        onSelect = { AppSettings.setOutputPcmMode(OutputPcmMode.entries[it]) },
                        modifier = Modifier.padding(start = TEXT_INSET, end = ROW_INSET, bottom = 14.dp),
                    )
                }
                val preferUsbDacTitle = stringResource(R.string.prefer_usb_dac)
                row(preferUsbDacTitle, "headphone", "output") {
                    SettingsSubRow(
                        title = preferUsbDacTitle,
                        checked = preferUsbDac,
                        onCheckedChange = AppSettings::setPreferUsbDac,
                        badge = stringResource(R.string.connected).takeIf { outputStatus.isUsb },
                    )
                }
                val loudnessTitle = stringResource(R.string.loudness_normalization)
                row(loudnessTitle, "loudness", "volume", "normalize", "replaygain", "lufs") {
                    SettingsRow(
                        icon = Icons.Rounded.VolumeUp,
                        title = loudnessTitle,
                        subtitle = stringResource(R.string.loudness_normalization_subtitle),
                        trailing = {
                            Switch(
                                checked = loudnessNormalization,
                                onCheckedChange = AppSettings::setLoudnessNormalization,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setLoudnessNormalization(!loudnessNormalization) },
                    )
                }
                val loudnessSpeakerTitle = stringResource(R.string.loudness_off_on_speaker)
                row(loudnessSpeakerTitle, "loudness", "speaker", "normalize") {
                    SettingsSubRow(
                        title = loudnessSpeakerTitle,
                        checked = loudnessOffOnSpeaker,
                        onCheckedChange = AppSettings::setLoudnessOffOnSpeaker,
                    )
                }
                // Automix decides its own length from each pair of tracks —
                // tempo, key, structure — so it replaces the manual slider rather
                // than needing it set to anything first.
                if (!smartFade) {
                    val crossfadeTitle = stringResource(R.string.crossfade)
                    row(crossfadeTitle, "fade", "gapless") {
                        SliderRow(
                            icon = Icons.Rounded.Waves,
                            title = crossfadeTitle,
                            subtitle = stringResource(R.string.crossfade_subtitle),
                            value = if (crossfade == 0) stringResource(R.string.off) else "${crossfade}s",
                            sliderValue = crossfade.toFloat(),
                            onSliderValue = { AppSettings.setCrossfadeSeconds(it.roundToInt()) },
                            valueRange = 0f..12f,
                            steps = 11,
                        )
                    }
                }
                val automixTitle = stringResource(R.string.automix)
                row(automixTitle, "crossfade", "smart fade", "mix") {
                    SettingsRow(
                        icon = Icons.Rounded.AutoAwesome,
                        title = automixTitle,
                        subtitle = if (smartFade) {
                            stringResource(R.string.automix_enabled_subtitle)
                        } else {
                            stringResource(R.string.automix_disabled_subtitle)
                        },
                        trailing = {
                            Switch(
                                checked = smartFade,
                                onCheckedChange = AppSettings::setSmartFadeEnabled,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setSmartFadeEnabled(!smartFade) },
                    )
                }
                val automixPerformanceTitle = stringResource(R.string.automix_performance)
                row(automixPerformanceTitle, "cpu", "battery") {
                    SettingsRow(
                        icon = SettingsIcons.Sound,
                        title = automixPerformanceTitle,
                        subtitle = stringResource(R.string.automix_performance_subtitle),
                        value = automixPerformance.localizedLabel(),
                        onClick = { pickingAutomixPerformance = true },
                    )
                }
                val skipSilenceTitle = stringResource(R.string.skip_silence)
                row(skipSilenceTitle, "silence") {
                    SettingsRow(
                        icon = Icons.AutoMirrored.Rounded.VolumeOff,
                        title = skipSilenceTitle,
                        // Silence skipping is Media3's own processor, and
                        // `DefaultAudioSink.configure` appends that processor list
                        // only on its 16-bit branch — the float branch gets the
                        // format converter and nothing else. So on a float track
                        // this switch really does nothing, and the row says so
                        // rather than letting someone toggle it and wonder. The
                        // equaliser is unaffected: it runs upstream of that sink.
                        subtitle = if (outputStatus.actualEncoding == AudioFormat.ENCODING_PCM_FLOAT) {
                            stringResource(R.string.skip_silence_float_subtitle)
                        } else {
                            stringResource(R.string.skip_silence_subtitle)
                        },
                        trailing = {
                            Switch(
                                checked = skipSilence,
                                onCheckedChange = AppSettings::setSkipSilence,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setSkipSilence(!skipSilence) },
                    )
                }
                val spatialAudioTitle = stringResource(R.string.spatial_audio)
                row(spatialAudioTitle, "surround", "3d") {
                    SettingsRow(
                        icon = Icons.Rounded.SurroundSound,
                        title = spatialAudioTitle,
                        // Widening a JOC stream would fight the object-based mix
                        // Dolby has already spatialized, so the service holds this
                        // off for the duration of an Atmos track — see
                        // `PlaybackService.applySpatialAudioEnabled`. Said on the
                        // row because the switch stays where the listener left it,
                        // and a switch reading "on" over an effect that is not
                        // running is the same silent lie the equaliser screen used
                        // to tell.
                        subtitle = if (playingDolbyAtmos) {
                            stringResource(R.string.spatial_audio_atmos_subtitle)
                        } else {
                            stringResource(R.string.spatial_audio_subtitle)
                        },
                        trailing = {
                            Switch(
                                checked = spatialAudio,
                                onCheckedChange = AppSettings::setSpatialAudio,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setSpatialAudio(!spatialAudio) },
                    )
                }
                // The system panel is not listed here as well. A device with a
                // Dolby or Dirac panel has something Veyra cannot reproduce and
                // keeps its row — but one level in, at the foot of the equaliser
                // screen, rather than as a second equaliser entry alongside ours.
                val equalizerTitle = stringResource(R.string.equalizer)
                row(equalizerTitle, "eq", "bass", "treble") {
                    SettingsRow(
                        icon = SettingsIcons.Sound,
                        title = equalizerTitle,
                        subtitle = stringResource(R.string.equalizer_subtitle),
                        onClick = onEqualizer,
                    )
                }
            }

            SearchableSettingsGroup(search, category = SettingsCategory.APPEARANCE, header = stringResource(R.string.appearance)) {
                val themeTitle = stringResource(R.string.theme)
                row(themeTitle, "dark mode", "light mode") {
                    SettingsRow(icon = Icons.Rounded.Brightness4, title = themeTitle)
                    SegmentedControl(
                        options = ThemeMode.entries.map { it.localizedLabel() },
                        selectedIndex = ThemeMode.entries.indexOf(theme),
                        onSelect = { AppSettings.setThemeMode(ThemeMode.entries[it]) },
                        modifier = Modifier.padding(start = ROW_INSET, end = ROW_INSET, bottom = 14.dp),
                    )
                }
                val liquidGlassTitle = stringResource(R.string.liquid_glass)
                row(liquidGlassTitle, "glass", "blur") {
                    SettingsRow(
                        icon = Icons.Rounded.AutoAwesome,
                        title = liquidGlassTitle,
                        subtitle = stringResource(
                            if (liquidGlassSupported) {
                                R.string.liquid_glass_subtitle
                            } else {
                                R.string.liquid_glass_unavailable
                            },
                        ),
                        enabled = liquidGlassSupported,
                        trailing = {
                            Switch(
                                checked = liquidGlass,
                                onCheckedChange = AppSettings::setLiquidGlass,
                                enabled = liquidGlassSupported,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setLiquidGlass(!liquidGlass) },
                    )
                }
                // Left out where the player won't honour it: a window too wide for
                // the player to fill and too narrow to stand a page beside it keeps
                // the sleeve either way. A docked pane is a phone's width, so it does
                // honour it — see [fullBleedArtworkAvailable].
                if (fullBleedArtworkAvailable(windowWidth)) {
                    val fullScreenCoverArtTitle = stringResource(R.string.full_screen_cover_art)
                    row(fullScreenCoverArtTitle, "artwork", "player") {
                        SettingsRow(
                            icon = Icons.Rounded.Fullscreen,
                            title = fullScreenCoverArtTitle,
                            subtitle = stringResource(R.string.full_screen_cover_art_subtitle),
                            trailing = {
                                Switch(
                                    checked = fullBleedArtwork,
                                    onCheckedChange = AppSettings::setFullBleedArtwork,
                                    colors = veyraSwitchColors(),
                                )
                            },
                            onClick = { AppSettings.setFullBleedArtwork(!fullBleedArtwork) },
                        )
                    }
                }
                val legacyMeshGradientTitle = stringResource(R.string.legacy_mesh_gradient)
                row(legacyMeshGradientTitle, "background", "player") {
                    SettingsRow(
                        icon = Icons.Rounded.Gradient,
                        title = legacyMeshGradientTitle,
                        subtitle = stringResource(R.string.legacy_mesh_gradient_subtitle),
                        trailing = {
                            Switch(
                                checked = legacyMeshGradient,
                                onCheckedChange = AppSettings::setLegacyMeshGradient,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setLegacyMeshGradient(!legacyMeshGradient) },
                    )
                }
                val animatedCoverArtTitle = stringResource(R.string.animated_cover_art)
                // Carries the keywords of the rows that only appear once it is on,
                // so searching "spotify" with animated covers switched off turns up
                // the switch that brings the Spotify row back rather than nothing.
                row(animatedCoverArtTitle, "canvas", "video", "spotify") {
                    SettingsRow(
                        icon = Icons.Rounded.Animation,
                        title = animatedCoverArtTitle,
                        subtitle = stringResource(R.string.animated_cover_art_subtitle),
                        trailing = {
                            Switch(
                                checked = animatedCanvas,
                                onCheckedChange = AppSettings::setAnimatedCanvas,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setAnimatedCanvas(!animatedCanvas) },
                    )
                }
                // Reads as part of the Animated cover art option above it, not
                // as a separate setting. Nothing to narrow while the clip itself
                // is off. Defaults to off: a clip loops for as long as its track
                // plays, so on cellular this is not a one-time video cost but
                // that cost repeated on every loop — see AppSettings.canvasOverCellular.
                if (animatedCanvas) {
                    val coverCellularTitle = stringResource(R.string.animated_cover_cellular)
                    row(coverCellularTitle, "canvas", "cellular", divided = false) {
                        SettingsSubRow(
                            title = coverCellularTitle,
                            checked = canvasOverCellular,
                            onCheckedChange = AppSettings::setCanvasOverCellular,
                        )
                    }
                    val spotifyCanvasTitle = stringResource(R.string.integrate_spotify_canvas)
                    row(spotifyCanvasTitle, "spotify", "canvas", divided = false) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(onClick = onSpotifyCanvasAuth)
                                .padding(start = ROW_INSET, end = ROW_INSET, top = 4.dp, bottom = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = spotifyCanvasTitle,
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onBackground,
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Chevron()
                        }
                    }
                }
                val artistSignaturesTitle = stringResource(R.string.artist_signatures)
                row(artistSignaturesTitle, "signature", "artist", "logo") {
                    SettingsRow(
                        icon = SettingsIcons.Appearance,
                        title = artistSignaturesTitle,
                        subtitle = stringResource(R.string.artist_signatures_subtitle),
                        trailing = {
                            Switch(
                                checked = signatureApiEnabled,
                                onCheckedChange = AppSettings::setSignatureApiEnabled,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setSignatureApiEnabled(!signatureApiEnabled) },
                    )
                }
                if (signatureApiEnabled) {
                    val signatureUrlTitle = stringResource(R.string.artist_signatures_url)
                    row(signatureUrlTitle, "signature", "api", "url", divided = false) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(onClick = onEditSignatureApi)
                                .padding(start = ROW_INSET, end = ROW_INSET, top = 4.dp, bottom = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = signatureApiUrl.ifBlank {
                                    stringResource(R.string.artist_signatures_unconfigured)
                                },
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onBackground,
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Chevron()
                        }
                    }
                }
                val syncedLyricsTitle = stringResource(R.string.synced_lyrics)
                // Same reasoning as Animated cover art above: the lyrics source and
                // translation rows are only here while this is on.
                row(syncedLyricsTitle, "lyrics", "translation", "lrclib", "musixmatch") {
                    SettingsRow(
                        icon = Icons.AutoMirrored.Rounded.Notes,
                        title = syncedLyricsTitle,
                        subtitle = stringResource(R.string.synced_lyrics_subtitle),
                        trailing = {
                            Switch(
                                checked = syncedLyrics,
                                onCheckedChange = AppSettings::setSyncedLyrics,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setSyncedLyrics(!syncedLyrics) },
                    )
                }
                // Nothing to choose between while the feature is off, and the
                // sources are third-party services being reached on the user's
                // connection — which is the part worth being able to narrow.
                if (syncedLyrics) {
                    val lyricsBlurTitle = stringResource(R.string.blur_unfocused_lyrics)
                    row(lyricsBlurTitle, "lyrics", "blur") {
                        SettingsRow(
                            icon = Icons.Rounded.BlurOn,
                            title = lyricsBlurTitle,
                            subtitle = stringResource(R.string.blur_unfocused_lyrics_subtitle),
                            trailing = {
                                Switch(
                                    checked = lyricsBlur,
                                    onCheckedChange = AppSettings::setLyricsBlur,
                                    colors = veyraSwitchColors(),
                                )
                            },
                            onClick = { AppSettings.setLyricsBlur(!lyricsBlur) },
                        )
                    }
                    val lyricsSourcesTitle = stringResource(R.string.lyrics_sources)
                    row(lyricsSourcesTitle, "lyrics", "lrclib", "musixmatch") {
                        SettingsRow(
                            icon = Icons.Rounded.Language,
                            title = lyricsSourcesTitle,
                            subtitle = lyricsSources
                                .sortedBy { it.ordinal }
                                .joinToString(", ") { it.label }
                                .ifEmpty { stringResource(R.string.no_lyrics_sources_enabled) },
                            trailing = { Chevron() },
                            onClick = onLyricsSources,
                        )
                    }
                    val translationLanguageTitle = stringResource(R.string.translation_language)
                    row(translationLanguageTitle, "lyrics", "translate") {
                        SettingsRow(
                            icon = Icons.Rounded.Translate,
                            title = translationLanguageTitle,
                            subtitle = if (translationLanguage.isBlank()) {
                                stringResource(R.string.translation_language_subtitle)
                            } else {
                                translationLanguageName(
                                    translationLanguage,
                                    AppCompatDelegate.getApplicationLocales().get(0) ?: Locale.getDefault(),
                                )
                            },
                            trailing = { Chevron() },
                            onClick = onTranslationLanguage,
                        )
                    }
                }
            }

            SearchableSettingsGroup(search, category = SettingsCategory.PERFORMANCE, header = stringResource(R.string.performance)) {
                val reduceAnimationTitle = stringResource(R.string.reduce_animation)
                row(reduceAnimationTitle, "motion") {
                    SettingsRow(
                        icon = Icons.Rounded.MotionPhotosOff,
                        title = reduceAnimationTitle,
                        subtitle = stringResource(R.string.reduce_animation_subtitle),
                        trailing = {
                            Switch(
                                checked = reduceAnimation,
                                onCheckedChange = AppSettings::setReduceAnimation,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setReduceAnimation(!reduceAnimation) },
                    )
                }
                val reduceDynamicBlurTitle = stringResource(R.string.reduce_dynamic_blur)
                row(reduceDynamicBlurTitle, "blur", "performance") {
                    SettingsRow(
                        icon = Icons.Rounded.BlurOff,
                        title = reduceDynamicBlurTitle,
                        subtitle = stringResource(R.string.reduce_dynamic_blur_subtitle),
                        trailing = {
                            Switch(
                                checked = reduceDynamicBlur,
                                onCheckedChange = AppSettings::setReduceDynamicBlur,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setReduceDynamicBlur(!reduceDynamicBlur) },
                    )
                }
                val highPerformanceModeTitle = stringResource(R.string.high_performance_mode)
                row(highPerformanceModeTitle, "frame rate", "refresh rate", "hz", "battery", "smooth") {
                    SettingsRow(
                        icon = VeyraIcons.Performance,
                        title = highPerformanceModeTitle,
                        subtitle = if (highPerformanceMode) {
                            stringResource(R.string.high_performance_active, selectedPerformanceRefreshRate)
                        } else {
                            stringResource(R.string.high_performance_subtitle)
                        },
                        trailing = {
                            Switch(
                                checked = highPerformanceMode,
                                onCheckedChange = { enabled ->
                                    if (enabled) {
                                        showPerformanceWarning = true
                                    } else {
                                        AppSettings.setHighPerformanceMode(false)
                                    }
                                },
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = {
                            if (highPerformanceMode) {
                                AppSettings.setHighPerformanceMode(false)
                            } else {
                                showPerformanceWarning = true
                            }
                        },
                    )
                }
                if (highPerformanceMode) {
                    val refreshRateTitle = stringResource(R.string.refresh_rate)
                    row(refreshRateTitle, "hz", "frame rate") {
                        SettingsRow(
                            icon = VeyraIcons.FrameRate,
                            title = refreshRateTitle,
                        )
                        SegmentedControl(
                            options = supportedRefreshRates.map { "$it Hz" },
                            selectedIndex = supportedRefreshRates.indexOf(selectedPerformanceRefreshRate),
                            onSelect = { index ->
                                AppSettings.setPerformanceRefreshRate(supportedRefreshRates[index])
                            },
                            modifier = Modifier.padding(
                                start = TEXT_INSET,
                                end = ROW_INSET,
                                bottom = 14.dp,
                            ),
                        )
                    }
                }
            }

            SearchableSettingsGroup(search, category = SettingsCategory.LIBRARY, header = stringResource(R.string.local_music)) {
                val localMusicFolderTitle = stringResource(R.string.local_music_folder)
                row(localMusicFolderTitle, "folder", "offline", "files") {
                    SettingsRow(
                        icon = Icons.Rounded.Folder,
                        title = localMusicFolderTitle,
                        subtitle = LocalMediaRepository.selectedFolderLabel(localMusicFolderUri)
                            ?: stringResource(R.string.all_audio_folders),
                        onClick = { localMusicFolderPicker.launch(null) },
                    )
                }
                if (localMusicFolderUri.isNotBlank()) {
                    val useAllAudioFoldersTitle = stringResource(R.string.use_all_audio_folders)
                    row(useAllAudioFoldersTitle, "folder") {
                        SettingsRow(
                            icon = SettingsIcons.Library,
                            title = useAllAudioFoldersTitle,
                            subtitle = stringResource(R.string.use_all_audio_folders_subtitle),
                            onClick = { AppSettings.setLocalMusicFolderUri("") },
                        )
                    }
                }
                val filterNonMusicAudioTitle = stringResource(R.string.filter_non_music_audio)
                row(filterNonMusicAudioTitle, "podcast", "recording") {
                    SettingsRow(
                        icon = Icons.Rounded.FilterAlt,
                        title = filterNonMusicAudioTitle,
                        subtitle = stringResource(R.string.filter_non_music_audio_subtitle),
                        trailing = {
                            Switch(
                                checked = filterNonMusicAudio,
                                onCheckedChange = AppSettings::setFilterNonMusicAudio,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setFilterNonMusicAudio(!filterNonMusicAudio) },
                    )
                }
            }

            val cacheUnlimited = cacheLimitBytes == AppSettings.UNLIMITED_CACHE_LIMIT_BYTES
            // The slider's last stop, one step past the largest fixed size, is
            // "Unlimited" — see [AppSettings.setAudioCacheLimitBytes].
            val cacheLimitMb = if (cacheUnlimited) CACHE_UNLIMITED_STOP_MB else (cacheLimitBytes / (1024 * 1024)).toInt()
            val unlimitedLabel = stringResource(R.string.song_cache_unlimited)
            val cacheLimitLabel = if (cacheUnlimited) unlimitedLabel else formatCacheSize(cacheLimitMb)
            SearchableSettingsGroup(search, category = SettingsCategory.LIBRARY, header = stringResource(R.string.storage)) {
                val showCacheFolderTitle = stringResource(R.string.show_cache_folder)
                row(showCacheFolderTitle, "cache", "cached songs", "library", "folder") {
                    SettingsRow(
                        icon = Icons.Rounded.Cached,
                        title = showCacheFolderTitle,
                        subtitle = stringResource(R.string.show_cache_folder_subtitle),
                        trailing = {
                            Switch(
                                checked = showCacheFolder,
                                onCheckedChange = AppSettings::setShowCacheFolder,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setShowCacheFolder(!showCacheFolder) },
                    )
                }
                val songCacheLimitTitle = stringResource(R.string.song_cache_limit)
                row(songCacheLimitTitle, "cache", "space", "unlimited") {
                    SliderRow(
                        icon = Icons.Rounded.Storage,
                        title = songCacheLimitTitle,
                        subtitle = when {
                            cacheUnlimited -> stringResource(R.string.song_cache_unlimited_subtitle)
                            cacheLimitMb > CACHE_WARNING_MB ->
                                stringResource(R.string.song_cache_large_subtitle, cacheLimitLabel)
                            else -> stringResource(R.string.song_cache_limit_subtitle)
                        },
                        value = cacheLimitLabel,
                        sliderValue = cacheLimitMb.toFloat(),
                        onSliderValue = {
                            AppSettings.setAudioCacheLimitBytes(it.roundToInt().toLong() * 1024 * 1024)
                        },
                        valueRange = (AppSettings.DEFAULT_CACHE_LIMIT_BYTES / (1024 * 1024)).toFloat()..
                            CACHE_UNLIMITED_STOP_MB.toFloat(),
                        steps = 19,
                    )
                }
                val clearSongCacheTitle = stringResource(R.string.clear_song_cache)
                row(clearSongCacheTitle, "cache", "free space") {
                    SettingsRow(
                        icon = Icons.Rounded.DeleteSweep,
                        title = clearSongCacheTitle,
                        subtitle = stringResource(R.string.clear_song_cache_subtitle),
                        onClick = { confirmClearSongCache = true },
                    )
                }
                val clearImageCacheTitle = stringResource(R.string.clear_image_cache)
                row(clearImageCacheTitle, "cache", "artwork", "free space") {
                    SettingsRow(
                        icon = Icons.Rounded.DeleteSweep,
                        title = clearImageCacheTitle,
                        subtitle = stringResource(R.string.clear_image_cache_subtitle),
                        onClick = {
                            val loader = SingletonImageLoader.get(context)
                            loader.memoryCache?.clear()
                            loader.diskCache?.clear()
                            Toast.makeText(context, context.getString(R.string.image_cache_cleared), Toast.LENGTH_SHORT).show()
                        },
                    )
                }
            }

            SearchableSettingsGroup(search, category = SettingsCategory.LIBRARY, header = stringResource(R.string.your_data)) {
                val replayTitle = stringResource(R.string.replay)
                row(replayTitle, "stats", "history", "wrapped") {
                    SettingsRow(
                        icon = Icons.Rounded.BarChart,
                        title = replayTitle,
                        subtitle = stringResource(R.string.replay_subtitle),
                        onClick = onOpenReplay,
                    )
                }
                val workOutGenresTitle = stringResource(R.string.work_out_genres)
                row(workOutGenresTitle, "genre", "replay") {
                    SettingsRow(
                        icon = Icons.Rounded.LocalOffer,
                        title = workOutGenresTitle,
                        subtitle = if (replayGenres) {
                            stringResource(R.string.replay_genres_enabled_subtitle)
                        } else {
                            stringResource(R.string.replay_genres_disabled_subtitle)
                        },
                        trailing = {
                            Switch(
                                checked = replayGenres,
                                onCheckedChange = AppSettings::setReplayGenres,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setReplayGenres(!replayGenres) },
                    )
                }
                val exportDataTitle = stringResource(R.string.export_data)
                row(exportDataTitle, "backup") {
                    SettingsRow(
                        icon = Icons.Rounded.FileUpload,
                        title = exportDataTitle,
                        subtitle = exportStatus ?: stringResource(R.string.export_data_subtitle),
                        onClick = { exportPicker.launch(Backup.suggestedName()) },
                    )
                }
                val importDataTitle = stringResource(R.string.import_data)
                row(importDataTitle, "backup", "restore") {
                    SettingsRow(
                        icon = Icons.Rounded.FileDownload,
                        title = importDataTitle,
                        subtitle = importStatus ?: stringResource(R.string.import_data_subtitle),
                        onClick = { confirmImport = true },
                    )
                }
            }

            // No footer: it only restated the stop-on-close row's own subtitle,
            // which sits four rows above it and says the same thing in fewer words.
            SearchableSettingsGroup(search, category = SettingsCategory.ADVANCED, header = stringResource(R.string.miscellaneous)) {
                val playNextOnSwipeTitle = stringResource(R.string.play_next_on_swipe)
                row(playNextOnSwipeTitle, "swipe", "queue") {
                    SettingsRow(
                        icon = Icons.Rounded.PlaylistPlay,
                        title = playNextOnSwipeTitle,
                        subtitle = if (swipeToPlayNext) {
                            stringResource(R.string.swipe_plays_next)
                        } else {
                            stringResource(R.string.swipe_adds_to_queue)
                        },
                        trailing = {
                            Switch(
                                checked = swipeToPlayNext,
                                onCheckedChange = AppSettings::setSwipeToPlayNext,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setSwipeToPlayNext(!swipeToPlayNext) },
                    )
                }
                val dontRepeatSongsTitle = stringResource(R.string.dont_repeat_songs)
                row(dontRepeatSongsTitle, "radio", "suggestions") {
                    SettingsRow(
                        icon = Icons.Rounded.History,
                        title = dontRepeatSongsTitle,
                        subtitle = stringResource(R.string.dont_repeat_songs_subtitle),
                        trailing = {
                            Switch(
                                checked = dontRepeatSuggestions,
                                onCheckedChange = AppSettings::setDontRepeatSuggestions,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setDontRepeatSuggestions(!dontRepeatSuggestions) },
                    )
                }
                val stopMusicOnCloseTitle = stringResource(R.string.stop_music_on_close)
                row(stopMusicOnCloseTitle, "notification", "background") {
                    SettingsRow(
                        icon = Icons.Rounded.MusicOff,
                        title = stopMusicOnCloseTitle,
                        subtitle = stringResource(R.string.stop_music_on_close_subtitle),
                        trailing = {
                            Switch(
                                checked = stopOnTaskRemoved,
                                onCheckedChange = AppSettings::setStopOnTaskRemoved,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setStopOnTaskRemoved(!stopOnTaskRemoved) },
                    )
                }
                val hideVolumeBarTitle = stringResource(R.string.hide_volume_bar)
                row(hideVolumeBarTitle, "volume", "player") {
                    SettingsRow(
                        icon = Icons.Rounded.VolumeOff,
                        title = hideVolumeBarTitle,
                        subtitle = stringResource(R.string.hide_volume_bar_subtitle),
                        trailing = {
                            Switch(
                                checked = hideVolumeBar,
                                onCheckedChange = AppSettings::setHideVolumeBar,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setHideVolumeBar(!hideVolumeBar) },
                    )
                }
                val hideStatusBarTitle = stringResource(R.string.hide_status_bar_in_player)
                row(hideStatusBarTitle, "status bar", "immersive", "fullscreen", "player") {
                    SettingsRow(
                        icon = Icons.Rounded.WebAssetOff,
                        title = hideStatusBarTitle,
                        subtitle = stringResource(R.string.hide_status_bar_in_player_subtitle),
                        trailing = {
                            Switch(
                                checked = hideStatusBarInPlayer,
                                onCheckedChange = AppSettings::setHideStatusBarInPlayer,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setHideStatusBarInPlayer(!hideStatusBarInPlayer) },
                    )
                }
                val showQueueHistoryTitle = stringResource(R.string.show_queue_history)
                row(showQueueHistoryTitle, "player", "queue", "history", "previously played") {
                    SettingsRow(
                        icon = Icons.Rounded.History,
                        title = showQueueHistoryTitle,
                        subtitle = stringResource(R.string.show_queue_history_subtitle),
                        trailing = {
                            Switch(
                                checked = showQueueHistory,
                                onCheckedChange = AppSettings::setShowQueueHistory,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setShowQueueHistory(!showQueueHistory) },
                    )
                }
                val hideSongStatusTitle = stringResource(R.string.hide_song_status)
                row(hideSongStatusTitle, "player", "playing from", "played by") {
                    SettingsRow(
                        icon = Icons.Rounded.VisibilityOff,
                        title = hideSongStatusTitle,
                        subtitle = stringResource(R.string.hide_song_status_subtitle),
                        trailing = {
                            Switch(
                                checked = hideSongStatus,
                                onCheckedChange = AppSettings::setHideSongStatus,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setHideSongStatus(!hideSongStatus) },
                    )
                }
            }

            SearchableSettingsGroup(search, category = SettingsCategory.APPEARANCE, header = stringResource(R.string.app_icon)) {
                val appIconTitle = stringResource(R.string.app_icon)
                row(appIconTitle, "icon", "launcher", "logo", "glass", "frost") {
                    SettingsRow(icon = SettingsIcons.Icons, title = appIconTitle, subtitle = stringResource(R.string.app_icon_picker_hint))
                    AppIconPicker()
                }
            }

            SearchableSettingsGroup(search, category = SettingsCategory.APPEARANCE, header = stringResource(R.string.language)) {
                val appLanguageTitle = stringResource(R.string.app_language)
                row(appLanguageTitle, "locale", "translate") {
                    val selectedLanguage = AppCompatDelegate.getApplicationLocales().get(0)?.toLanguageTag()
                        ?: Locale.getDefault().toLanguageTag()
                    SettingsRow(
                        icon = Icons.Rounded.Language,
                        title = appLanguageTitle,
                        subtitle = stringResource(languageDisplayNameRes(selectedLanguage)),
                        onClick = onAppLanguage,
                    )
                }
            }

            SearchableSettingsGroup(search, category = SettingsCategory.ADVANCED, header = stringResource(R.string.advanced_options)) {
                val smartAlignmentTitle = stringResource(R.string.smart_version_alignment)
                row(smartAlignmentTitle, "alignment", "sync", "waveform", "video", "audio", "skit", "intro") {
                    SettingsRow(
                        icon = Icons.Rounded.GraphicEq,
                        title = smartAlignmentTitle,
                        subtitle = stringResource(R.string.smart_version_alignment_subtitle),
                        trailing = {
                            Switch(
                                checked = smartVersionAlignment,
                                onCheckedChange = AppSettings::setSmartVersionAlignment,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setSmartVersionAlignment(!smartVersionAlignment) },
                    )
                }
                val showNerdStatsTitle = stringResource(R.string.show_nerd_stats)
                row(showNerdStatsTitle, "debug", "bitrate", "codec") {
                    SettingsRow(
                        icon = Icons.Rounded.BarChart,
                        title = showNerdStatsTitle,
                        subtitle = stringResource(R.string.show_nerd_stats_subtitle),
                        trailing = {
                            Switch(
                                checked = nerdStats,
                                onCheckedChange = AppSettings::setShowNerdStats,
                                colors = veyraSwitchColors(),
                            )
                        },
                        onClick = { AppSettings.setShowNerdStats(!nerdStats) },
                    )
                }

            }

            if (category == null || searching) {
                val creatorTitle = stringResource(R.string.creator_instagram)
                if (!searching || search.matches(creatorTitle, "instagram", "bhavishya_dalal_", "creator")) {
                    Column(Modifier.padding(horizontal = GROUP_INSET, vertical = 12.dp)) {
                        SettingsRow(
                            icon = SettingsIcons.Instagram,
                            title = creatorTitle,
                            subtitle = stringResource(R.string.creator_instagram_handle),
                            onClick = {
                                runCatching {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/bhavishya_dalal_/")))
                                }.onFailure {
                                    Toast.makeText(context, context.getString(R.string.creator_link_unavailable), Toast.LENGTH_SHORT).show()
                                }
                            },
                        )
                    }
                }
            }

            // Read after every group above has had its turn at the query, which is
            // what makes this an accurate "nothing here" rather than a guess.
            if (searching && !search.anyMatch) {
                MessageState(
                    stringResource(R.string.settings_search_empty, searchQuery),
                    actionLabel = stringResource(R.string.clear_search),
                    onAction = { searchQuery = "" },
                )
            }

            // The version line is the page's colophon, not a setting: it belongs to
            // the whole list, so it goes when the list is narrowed to a few rows.
            if (searchQuery.isBlank()) {
                Text(
                    text = "Veyra $version",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 24.dp, bottom = 8.dp),
                )
            }
        }
    }

    picking?.let { target ->
        ModalBottomSheet(
            onDismissRequest = { picking = null },
            containerColor = MaterialTheme.colorScheme.background,
        ) {
            QualitySheet(
                target = target,
                selected = when (target) {
                    QualityTarget.WIFI -> wifiQuality
                    QualityTarget.CELLULAR -> cellularQuality
                },
                // Writes the one ceiling that was being edited and nothing
                // else. There used to be a `SourceRegistry.applyQualityPreset`
                // call here that flipped the module and JioSaavn switches to
                // match — which meant budgeting *mobile data* switched those
                // sources off while sitting on Wi-Fi, and coming back to Wi-Fi
                // never switched them on again. Which sources a rung consults
                // is now read per stream off the connection in force; see
                // [AudioQuality.permits].
                onSelect = { quality ->
                    when (target) {
                        QualityTarget.WIFI -> AppSettings.setAudioQualityWifi(quality)
                        QualityTarget.CELLULAR -> AppSettings.setAudioQualityCellular(quality)
                    }
                    picking = null
                },
            )
        }
    }

    if (pickingDownloadQuality) {
        ModalBottomSheet(
            onDismissRequest = { pickingDownloadQuality = false },
            containerColor = MaterialTheme.colorScheme.background,
        ) {
            DownloadQualitySheet(
                selected = downloadQuality,
                onSelect = { quality ->
                    AppSettings.setDownloadQuality(quality)
                    pickingDownloadQuality = false
                },
            )
        }
    }

    if (pickingAutomixPerformance) {
        ModalBottomSheet(
            onDismissRequest = { pickingAutomixPerformance = false },
            containerColor = MaterialTheme.colorScheme.background,
        ) {
            AutomixPerformanceSheet(
                selected = automixPerformance,
                onSelect = { mode ->
                    AppSettings.setAutomixPerformanceMode(mode)
                    pickingAutomixPerformance = false
                },
            )
        }
    }

    // Everything in the Cached songs folder goes with it, so say so first.
    if (confirmClearSongCache) {
        AlertDialog(
            onDismissRequest = { confirmClearSongCache = false },
            title = { Text(stringResource(R.string.clear_song_cache_title)) },
            text = { Text(stringResource(R.string.clear_song_cache_warning)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmClearSongCache = false
                    AudioCache.clear {
                        Toast.makeText(context, context.getString(R.string.song_cache_cleared), Toast.LENGTH_SHORT).show()
                    }
                }) {
                    Text(stringResource(R.string.clear))
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmClearSongCache = false }) {
                    Text(stringResource(R.string.cancel))
                }
            },
        )
    }

    // Asked before the picker opens rather than after a file is chosen: the
    // thing being confirmed is that this device's own history is about to be
    // thrown away, and that is true whichever file gets picked.
    if (confirmImport) {
        AlertDialog(
            onDismissRequest = { confirmImport = false },
            title = { Text(stringResource(R.string.import_backup_title)) },
            text = {
                Text(stringResource(R.string.import_backup_warning))
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmImport = false
                    importPicker.launch(arrayOf("application/json", "text/plain", "*/*"))
                }) {
                    Text(stringResource(R.string.choose_file))
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmImport = false }) {
                    Text(stringResource(R.string.cancel))
                }
            },
        )
    }

    if (showPerformanceWarning) {
        AlertDialog(
            onDismissRequest = { showPerformanceWarning = false },
            title = { Text(stringResource(R.string.high_performance_before_enabling)) },
            text = { Text(stringResource(R.string.high_performance_battery_warning)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showPerformanceWarning = false
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = Uri.fromParts("package", context.packageName, null)
                        }
                        val settingsIntent = intent.takeIf {
                            it.resolveActivity(context.packageManager) != null
                        } ?: Intent(Settings.ACTION_SETTINGS)
                        batterySettingsLauncher.launch(settingsIntent)
                    },
                ) {
                    Text(stringResource(R.string.open_battery_settings))
                }
            },
            dismissButton = {
                TextButton(onClick = { showPerformanceWarning = false }) {
                    Text(stringResource(R.string.cancel))
                }
            },
        )
    }

    if (showPerformanceConfirmation) {
        AlertDialog(
            onDismissRequest = { showPerformanceConfirmation = false },
            title = { Text(stringResource(R.string.enable_high_performance_title)) },
            text = { Text(stringResource(R.string.enable_high_performance_confirmation)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showPerformanceConfirmation = false
                        AppSettings.setHighPerformanceMode(true)
                    },
                ) {
                    Text(stringResource(R.string.enable))
                }
            },
            dismissButton = {
                TextButton(onClick = { showPerformanceConfirmation = false }) {
                    Text(stringResource(R.string.not_yet))
                }
            },
        )
    }

    if (showListenBrainzTokenDialog) {
        var tokenInput by remember { mutableStateOf(listenBrainzToken) }
        AlertDialog(
            onDismissRequest = { showListenBrainzTokenDialog = false },
            title = { Text(stringResource(R.string.listenbrainz_token)) },
            text = {
                OutlinedTextField(
                    value = tokenInput,
                    onValueChange = { tokenInput = it },
                    label = { Text(stringResource(R.string.api_token)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    AppSettings.setListenBrainzToken(tokenInput.trim())
                    showListenBrainzTokenDialog = false
                }) {
                    Text(stringResource(R.string.save))
                }
            },
            dismissButton = {
                TextButton(onClick = { showListenBrainzTokenDialog = false }) {
                    Text(stringResource(R.string.cancel))
                }
            },
        )
    }

    if (showLastfmLoginDialog) {
        var usernameInput by remember { mutableStateOf("") }
        var passwordInput by remember { mutableStateOf("") }
        var lastfmError by remember { mutableStateOf<String?>(null) }
        var lastfmLoading by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { if (!lastfmLoading) showLastfmLoginDialog = false },
            title = { Text(stringResource(R.string.lastfm_login)) },
            text = {
                Column {
                    if (lastfmError != null) {
                        Text(
                            text = lastfmError!!,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(bottom = 8.dp),
                        )
                    }
                    OutlinedTextField(
                        value = usernameInput,
                        onValueChange = { usernameInput = it },
                        label = { Text(stringResource(R.string.username)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = { passwordInput = it },
                        label = { Text(stringResource(R.string.password)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        lastfmLoading = true
                        lastfmError = null
                        scrobbleScope.launch {
                            try {
                                // Use the credentials supplied for this build.
                                LastFM.initialize(
                                    apiKey = AppSettings.lastfmApiKey.value,
                                    secret = AppSettings.lastfmSecret.value,
                                )
                                LastFM.getMobileSession(usernameInput.trim(), passwordInput)
                                    .onSuccess { auth ->
                                        AppSettings.setLastfmSessionKey(auth.session.key)
                                        AppSettings.setLastfmUsername(auth.session.name)
                                        AppSettings.setLastfmEnabled(true)
                                        showLastfmLoginDialog = false
                                    }
                                    .onFailure { e ->
                                        lastfmError = e.message ?: context.getString(R.string.login_failed)
                                    }
                            } catch (e: Exception) {
                                lastfmError = e.message ?: context.getString(R.string.login_failed)
                            } finally {
                                lastfmLoading = false
                            }
                        }
                    },
                    enabled = !lastfmLoading && usernameInput.isNotBlank() && passwordInput.isNotBlank(),
                ) {
                    Text(stringResource(if (lastfmLoading) R.string.signing_in else R.string.sign_in))
                }
            },
            dismissButton = {
                TextButton(onClick = { showLastfmLoginDialog = false }, enabled = !lastfmLoading) {
                    Text(stringResource(R.string.cancel))
                }
            },
        )
    }

}

/** "3 months of listening" — the unit a backup is actually measured in. */
private fun Context.countOfMonths(months: Int): String = if (months == 0) {
    getString(R.string.no_listening_history)
} else {
    resources.getQuantityString(R.plurals.listening_month_count, months, months)
}

/** Which ceiling the open picker is editing. */
private enum class QualityTarget(val icon: ImageVector) {
    WIFI(Icons.Rounded.Wifi),
    CELLULAR(SettingsIcons.Performance),
}

@Composable
private fun QualityTarget.localizedTitle(): String = stringResource(
    if (this == QualityTarget.WIFI) R.string.wifi else R.string.mobile_data,
)

@Composable
private fun AudioQuality.localizedLabel(): String = stringResource(
    when (this) {
        AudioQuality.LOW -> R.string.low
        AudioQuality.MEDIUM -> R.string.medium
        AudioQuality.HIGH -> R.string.high
        AudioQuality.LOSSLESS -> R.string.lossless
    },
)

@Composable
private fun DownloadQuality.localizedLabel(): String = stringResource(
    when (this) {
        DownloadQuality.STANDARD -> R.string.standard
        DownloadQuality.HIGH -> R.string.high
        DownloadQuality.LOSSLESS -> R.string.lossless
    },
)

@Composable
private fun ThemeMode.localizedLabel(): String = stringResource(
    when (this) {
        ThemeMode.SYSTEM -> R.string.system
        ThemeMode.LIGHT -> R.string.light
        ThemeMode.DARK -> R.string.dark
    },
)

@Composable
private fun AutomixPerformanceMode.localizedLabel(): String = stringResource(
    when (this) {
        AutomixPerformanceMode.EFFICIENT -> R.string.automix_mode_efficient
        AutomixPerformanceMode.BALANCED -> R.string.automix_mode_balanced
        AutomixPerformanceMode.PERFORMANCE -> R.string.automix_mode_performance
    },
)

/**
 * Hands the device's own effect panel this app's audio session.
 *
 * Shared with [EqualizerScreen], which offers the same escape hatch a second
 * time next to the equaliser it might be an alternative to.
 */
internal fun openEqualizer(context: Context, sessionId: Int) {
    val intent = Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL).apply {
        putExtra(AudioEffect.EXTRA_AUDIO_SESSION, sessionId)
        putExtra(AudioEffect.EXTRA_PACKAGE_NAME, context.packageName)
        putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)
    }
    runCatching { context.startActivity(intent) }.onFailure {
        Toast.makeText(context, context.getString(R.string.no_equalizer), Toast.LENGTH_SHORT).show()
    }
}

/** Above this, the cache limit slider's subtitle warns rather than reassures. */
private const val CACHE_WARNING_MB = 2048

/**
 * Where the cache limit slider's "Unlimited" stop sits: one 512MB step past
 * [AppSettings.MAX_CACHE_LIMIT_BYTES], so the fixed sizes keep their positions.
 */
private const val CACHE_UNLIMITED_STOP_MB = 10 * 1024 + 512

/** "512 MB", "2 GB", "2.5 GB" — whichever reads more naturally at that size. */
private fun formatCacheSize(mb: Int): String {
    if (mb < 1024) return "$mb MB"
    val gb = mb / 1024f
    return if (gb == gb.toInt().toFloat()) "${gb.toInt()} GB" else "%.1f GB".format(Locale.ROOT, gb)
}

/** Who you're signed in as, straight from YouTube Music's account menu. */
@Composable
internal fun AccountCard(
    signedIn: Boolean,
    account: Account?,
    onSignIn: () -> Unit,
    onClick: (() -> Unit)? = null,
    /** Sits inside a [SettingsGroup] that already supplies the card, so draws none of its own. */
    grouped: Boolean = false,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (grouped) {
                    Modifier
                } else {
                    Modifier
                        .padding(horizontal = GROUP_INSET)
                        .clip(GroupShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                },
            )
            .then(
                when {
                    signedIn && onClick != null -> Modifier.clickable(onClick = onClick)
                    !signedIn -> Modifier.clickable(onClick = onSignIn)
                    else -> Modifier
                },
            )
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (account?.thumbnailUrl != null) {
            AsyncImage(
                model = account.thumbnailUrl,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(52.dp).clip(CircleShape).thumbnailBorder(CircleShape),
            )
        } else {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.outline),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    SettingsIcons.Account,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = account?.name
                    ?: stringResource(if (signedIn) R.string.signed_in else R.string.not_signed_in),
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = account?.email?.takeIf { it.isNotBlank() }
                    ?: stringResource(
                        if (signedIn) R.string.youtube_music_account else R.string.tap_to_sign_in_google,
                    ),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (!signedIn) {
            Spacer(Modifier.width(8.dp))
            Chevron()
        }
    }
}

/** The quality options for one connection, with what each costs in data. */
@Composable
private fun QualitySheet(
    target: QualityTarget,
    selected: AudioQuality,
    onSelect: (AudioQuality) -> Unit,
) {
    val haptics = LocalHapticFeedback.current
    Column(Modifier.fillMaxWidth().padding(bottom = 24.dp)) {
        Row(
            modifier = Modifier.padding(start = 22.dp, end = 22.dp, bottom = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = target.icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.size(22.dp),
            )
            Spacer(Modifier.width(14.dp))
            Column {
                Text(
                    text = stringResource(R.string.audio_quality),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Text(
                    text = stringResource(
                        R.string.audio_quality_connection,
                        target.localizedTitle().lowercase(Locale.getDefault()),
                    ),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outline)

        // Best first — the option most people want shouldn't be last.
        AudioQuality.entries.reversed().forEach { quality ->
            val chosen = quality == selected
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onSelect(quality)
                    }
                    .padding(horizontal = 22.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = quality.localizedLabel(),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        text = stringResource(R.string.quality_hourly, quality.detail, quality.hourly),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (chosen) {
                    Spacer(Modifier.width(12.dp))
                    Icon(
                        Icons.Rounded.Check,
                        contentDescription = stringResource(R.string.selected),
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp),
                    )
                }
            }
        }
    }
}

/** CPU budget picker for the background models that prepare Automix. */
@Composable
private fun AutomixPerformanceSheet(
    selected: AutomixPerformanceMode,
    onSelect: (AutomixPerformanceMode) -> Unit,
) {
    val haptics = LocalHapticFeedback.current
    Column(Modifier.fillMaxWidth().padding(bottom = 24.dp)) {
        Row(
            modifier = Modifier.padding(start = 22.dp, end = 22.dp, bottom = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = SettingsIcons.Sound,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.size(22.dp),
            )
            Spacer(Modifier.width(14.dp))
            Column {
                Text(
                    text = stringResource(R.string.automix_performance),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Text(
                    text = stringResource(R.string.automix_performance_warning),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outline)
        AutomixPerformanceMode.entries.forEach { mode ->
            val chosen = mode == selected
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onSelect(mode)
                    }
                    .padding(horizontal = 22.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = mode.localizedLabel(),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        text = stringResource(
                            when (mode) {
                                AutomixPerformanceMode.EFFICIENT -> R.string.automix_mode_efficient_subtitle
                                AutomixPerformanceMode.BALANCED -> R.string.automix_mode_balanced_subtitle
                                AutomixPerformanceMode.PERFORMANCE -> R.string.automix_mode_performance_subtitle
                            },
                        ),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (chosen) {
                    Spacer(Modifier.width(12.dp))
                    Icon(
                        Icons.Rounded.Check,
                        contentDescription = stringResource(R.string.selected),
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp),
                    )
                }
            }
        }
    }
}

/**
 * What to keep when a track is saved, with what each rung costs on disk.
 *
 * Priced per track rather than per hour, the way [QualitySheet] is. That sheet
 * is answering "what will listening cost me this hour", because a stream is
 * spent again on every replay; this one is answering "what will keeping this
 * cost me", and the answer is charged once. Same widget, different question, so
 * the numbers beside the options are in different units on purpose.
 */
@Composable
private fun DownloadQualitySheet(
    selected: DownloadQuality,
    onSelect: (DownloadQuality) -> Unit,
) {
    val haptics = LocalHapticFeedback.current
    Column(Modifier.fillMaxWidth().padding(bottom = 24.dp)) {
        Row(
            modifier = Modifier.padding(start = 22.dp, end = 22.dp, bottom = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = Icons.Rounded.Download,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.size(22.dp),
            )
            Spacer(Modifier.width(14.dp))
            Column {
                Text(
                    text = stringResource(R.string.download_quality),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Text(
                    text = stringResource(R.string.download_quality_dialog_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outline)

        // Best first, matching [QualitySheet] — and here the best rung is also
        // the default, so the checkmark starts where the eye does.
        DownloadQuality.entries.reversed().forEach { quality ->
            val chosen = quality == selected
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onSelect(quality)
                    }
                    .padding(horizontal = 22.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = quality.localizedLabel(),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        text = stringResource(R.string.quality_per_track, quality.detail, quality.perTrack),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (chosen) {
                    Spacer(Modifier.width(12.dp))
                    Icon(
                        Icons.Rounded.Check,
                        contentDescription = stringResource(R.string.selected),
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp),
                    )
                }
            }
        }
    }
}

// ---- Building blocks --------------------------------------------------------

internal val GroupShape = RoundedCornerShape(22.dp)
internal val GROUP_INSET = 16.dp
internal val ROW_INSET = 16.dp
internal val ICON_SIZE = 22.dp
internal val ICON_GAP = 14.dp

/** Where a row's text starts — dividers are inset to match, as on iOS. */
internal val TEXT_INSET = ROW_INSET + ICON_SIZE + ICON_GAP

/**
 * What is typed into the field under the Settings title, and whether anything
 * on the screen has answered to it.
 *
 * Categories use existing translated labels. Search spans them all; otherwise
 * only the selected category composes its controls.
 */
private enum class SettingsCategory(val title: Int, val summary: List<Int>, val icon: ImageVector) {
    ACCOUNT(R.string.account_integrations, listOf(R.string.scrobbling, R.string.listen_together), SettingsIcons.Account),
    SOUND(R.string.playback, listOf(R.string.audio_quality, R.string.equalizer), SettingsIcons.Sound),
    APPEARANCE(R.string.appearance, listOf(R.string.theme, R.string.app_icon), SettingsIcons.Appearance),
    LIBRARY(R.string.library, listOf(R.string.downloads, R.string.storage, R.string.your_data), SettingsIcons.Library),
    PERFORMANCE(R.string.performance, listOf(R.string.high_performance_mode, R.string.reduce_animation), SettingsIcons.Performance),
    ADVANCED(R.string.advanced_options, listOf(R.string.miscellaneous, R.string.show_nerd_stats), SettingsIcons.Advanced),
}

/** Plain, full-width destinations remain readable at large system font sizes. */
@Composable
private fun SettingsOverview(onSelect: (SettingsCategory) -> Unit) {
    Text(
        stringResource(R.string.settings_intro),
        style = MaterialTheme.typography.bodyLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = GROUP_INSET + ROW_INSET, vertical = 18.dp),
    )
    Column(Modifier.fillMaxWidth().padding(horizontal = GROUP_INSET)) {
        SettingsCategory.entries.forEachIndexed { index, category ->
            if (index > 0) RowDivider()
            SettingsRow(
                icon = category.icon,
                title = stringResource(category.title),
                subtitle = category.summary.map { stringResource(it) }.joinToString(" · "),
                onClick = { onSelect(category) },
            )
        }
    }
}

/** Collects the rows of one group that survived the search. */
private class SettingsGroupScope(
    private val search: SettingsSearch<SettingsCategory>,
    private val header: String?,
) {
    class Entry(val divided: Boolean, val content: @Composable () -> Unit)

    val entries = mutableListOf<Entry>()

    /**
     * One searchable setting. [keywords] is everything somebody might type
     * looking for it: its title at least, plus whatever its subtitle or the
     * controls under it say that the title doesn't — "Spotify", say, for the
     * canvas link that lives under Animated cover art.
     *
     * [divided] is false for the rows drawn as part of the row above them
     * rather than as settings in their own right, so they keep hugging their
     * parent when both survive the filter.
     */
    fun row(
        vararg keywords: String?,
        divided: Boolean = true,
        content: @Composable () -> Unit,
    ) {
        // The header counts for every row beneath it: searching "playback"
        // should turn up the playback group entire, not nothing at all.
        if (search.matches(header, *keywords)) entries += Entry(divided, content)
    }
}

/**
 * A [SettingsGroup] whose rows are filtered by the search field, and which
 * takes itself off the screen when none of them are left. Dividers fall
 * between the rows that survived rather than around the gaps left by the ones
 * that didn't, so a filtered section is indistinguishable from a hand-written one.
 */
@Composable
private fun SearchableSettingsGroup(
    search: SettingsSearch<SettingsCategory>,
    category: SettingsCategory,
    header: String? = null,
    footer: String? = null,
    topSpacing: Dp = 26.dp,
    content: @Composable SettingsGroupScope.() -> Unit,
) {
    // Do not compose controls for unopened categories. Search intentionally spans all categories.
    if (!search.includes(category)) return
    val scope = SettingsGroupScope(search, header)
    scope.content()
    if (scope.entries.isEmpty()) return
    SettingsGroup(header = header, footer = footer, topSpacing = topSpacing) {
        scope.entries.forEachIndexed { index, entry ->
            when {
                index > 0 && entry.divided -> RowDivider()
                // An undivided row is drawn tight to the top because something
                // it belongs to is usually above it. Filtered down to itself it
                // has nothing to sit under, so it is given that room back.
                index == 0 && !entry.divided -> Spacer(Modifier.height(10.dp))
            }
            entry.content()
        }
    }
}

/**
 * One section of rows, with a sentence-case heading above and an optional
 * plain-language [footer] below. Rows are separated by [RowDivider].
 */
@Composable
internal fun SettingsGroup(
    header: String? = null,
    footer: String? = null,
    /** Room above the section, where there is no [header] to provide it. */
    topSpacing: Dp = 26.dp,
    content: @Composable () -> Unit,
) {
    if (header != null) {
        Text(
            text = header,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.semantics { heading() }.padding(
                start = GROUP_INSET + 4.dp,
                end = GROUP_INSET,
                top = 26.dp,
                bottom = 8.dp,
            ),
        )
    } else {
        Spacer(Modifier.height(topSpacing))
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = GROUP_INSET),
    ) {
        content()
    }
    if (footer != null) {
        Text(
            text = footer,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(
                start = GROUP_INSET + 4.dp,
                end = GROUP_INSET + 4.dp,
                top = 8.dp,
            ),
        )
    }
}

@Composable
internal fun RowDivider() {
    HorizontalDivider(
        modifier = Modifier.padding(start = TEXT_INSET),
        thickness = 0.5.dp,
        color = MaterialTheme.colorScheme.outline,
    )
}

/**
 * The standard row: glyph, title, optional subtitle, and on the right either
 * [trailing] (a switch, say) or a chevron. The current [value] sits beneath the
 * label so it cannot squeeze long translated labels out of narrow screens.
 *
 * [iconPainter] is for the handful of rows whose glyph is a drawable rather
 * than a Material icon — the Dolby double-D, which is a mark and not something
 * to approximate with the nearest speaker outline. Exactly one of it and [icon]
 * is expected; the painter wins where both are given.
 */
@Composable
internal fun SettingsRow(
    icon: ImageVector? = null,
    title: String,
    subtitle: String? = null,
    subtitleContent: (@Composable () -> Unit)? = null,
    value: String? = null,
    badge: String? = null,
    enabled: Boolean = true,
    iconPainter: Painter? = null,
    onClick: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null && enabled) Modifier.clickable(onClick = onClick) else Modifier)
            .alpha(if (enabled) 1f else 0.45f)
            .heightIn(min = 64.dp)
            .padding(horizontal = ROW_INSET, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (iconPainter != null) {
            Icon(
                painter = iconPainter,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(ICON_SIZE),
            )
        } else if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(ICON_SIZE),
            )
        }
        Spacer(Modifier.width(ICON_GAP))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
                if (badge != null) {
                    Spacer(Modifier.width(8.dp))
                    Badge(badge)
                }
            }
            if (subtitleContent != null) {
                subtitleContent()
            } else if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 5,
                )
            }
            if (value != null) {
                Text(
                    text = value,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        if (trailing != null) {
            trailing()
        } else if (value != null || onClick != null) {
            Chevron()
        }
    }
}

/**
 * A toggle that reads as part of the option above it rather than a setting
 * of its own: no icon, no divider, and pulled up close against its parent
 * instead of getting the same breathing room a full [SettingsRow] gets.
 */
@Composable
internal fun SettingsSubRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    badge: String? = null,
    subtitle: String? = null,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(start = ROW_INSET, end = ROW_INSET, top = 0.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (badge != null) {
                    Spacer(Modifier.width(8.dp))
                    Badge(badge)
                }
            }
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 5,
                )
            }
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = veyraSwitchColors(),
        )
    }
}

/** Marks the connection whose ceiling is actually in force right now. */
@Composable
internal fun Badge(text: String) {
    Text(
        text = text.uppercase(Locale.ROOT),
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier
            .clip(RoundedCornerShape(5.dp))
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.16f))
            .padding(horizontal = 6.dp, vertical = 2.dp),
    )
}

@Composable
internal fun Chevron() {
    Icon(
        SettingsIcons.Chevron,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
        modifier = Modifier.size(20.dp),
    )
}

/** A continuous setting: label and current value on one line, track beneath. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun SliderRow(
    icon: ImageVector,
    title: String,
    value: String,
    sliderValue: Float,
    onSliderValue: (Float) -> Unit,
    valueRange: ClosedFloatingPointRange<Float>,
    steps: Int,
    subtitle: String? = null,
) {
    val colors = SliderDefaults.colors(
        thumbColor = MaterialTheme.colorScheme.primary,
        activeTrackColor = MaterialTheme.colorScheme.primary,
        inactiveTrackColor = MaterialTheme.colorScheme.outline,
    )
    Column(Modifier.padding(start = ROW_INSET, end = ROW_INSET, top = 12.dp, bottom = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.size(ICON_SIZE),
            )
            Spacer(Modifier.width(ICON_GAP))
            Column(Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                if (subtitle != null) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Spacer(Modifier.width(12.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Slider(
            value = sliderValue,
            onValueChange = onSliderValue,
            valueRange = valueRange,
            steps = steps,
            colors = colors,
            // Bare track: the step ticks and the end-stop dot are noise when the
            // value is already spelled out on the line above.
            track = { state ->
                SliderDefaults.Track(
                    sliderState = state,
                    colors = colors,
                    drawStopIndicator = null,
                    drawTick = { _, _ -> },
                )
            },
            modifier = Modifier.padding(start = ICON_SIZE + ICON_GAP),
        )
    }
}

/** Sign out: centered, accent-coloured, no glyph — the shape of a real one. */
@Composable
internal fun DestructiveRow(
    label: String,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 15.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.primary,
        )
    }
}

/** Sliding pill selector, for the handful of settings with two or three states. */
@Composable
internal fun SegmentedControl(
    options: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    val haptics = LocalHapticFeedback.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.outline)
            // Enough of a margin for the track to read as a track. At 2dp the
            // selected pill sat all but flush against the container's own edge,
            // so the two rounded rectangles merged into one shape and the
            // control stopped looking like something with a position in it.
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        options.forEachIndexed { index, label ->
            val chosen = index == selectedIndex
            val pill by animateColorAsState(
                targetValue = if (chosen) {
                    MaterialTheme.colorScheme.primary
                } else {
                    Color.Transparent
                },
                animationSpec = tween(160),
                label = "segmentPill",
            )
            val labelColor by animateColorAsState(
                targetValue = if (chosen) {
                    MaterialTheme.colorScheme.onPrimary
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
                animationSpec = tween(160),
                label = "segmentLabel",
            )
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(pill)
                    .clickable(enabled = enabled) {
                        if (!chosen) {
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onSelect(index)
                        }
                    }
                    .padding(vertical = 9.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelMedium,
                    color = labelColor,
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
private fun AppIconPicker() {
    val context = LocalContext.current
    var selected by remember { mutableStateOf(AppIcon.current(context)) }
    androidx.compose.foundation.layout.BoxWithConstraints(
        Modifier.fillMaxWidth().padding(horizontal = ROW_INSET, vertical = 8.dp),
    ) {
        val columns = if (maxWidth >= 340.dp) 3 else 2
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            AppIcon.entries.chunked(columns).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    row.forEach { option ->
                        val checked = option == selected
                        Column(
                            Modifier.weight(1f)
                                .clip(RoundedCornerShape(18.dp))
                                .background(if (checked) MaterialTheme.colorScheme.primary.copy(alpha = 0.10f) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.035f))
                                .border(if (checked) 2.dp else 1.dp,
                                    if (checked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(18.dp))
                                .selectable(selected = checked, role = Role.RadioButton, onClick = {
                                    if (!checked) {
                                        runCatching { AppIcon.apply(context, option) }
                                            .onSuccess {
                                                selected = AppIcon.current(context)
                                                Toast.makeText(context, context.getString(R.string.app_icon_changed), Toast.LENGTH_SHORT).show()
                                            }.onFailure {
                                                Toast.makeText(context, context.getString(R.string.app_icon_failed), Toast.LENGTH_SHORT).show()
                                            }
                                    }
                                })
                                .padding(horizontal = 6.dp, vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Box(Modifier.size(68.dp).clip(RoundedCornerShape(18.dp))) {
                                val preview = option.previewRes
                                if (preview != null) {
                                    Image(painterResource(preview), null, modifier = Modifier.fillMaxSize().scale(1.5f), contentScale = ContentScale.Fit)
                                } else {
                                    AndroidView(factory = { ctx -> android.widget.ImageView(ctx) },
                                        update = { it.setImageResource(option.iconRes) }, modifier = Modifier.fillMaxSize())
                                }
                            }
                            Text(stringResource(option.labelRes), textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (checked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                fontWeight = if (checked) FontWeight.Bold else FontWeight.Medium,
                                modifier = Modifier.padding(top = 8.dp))
                        }
                    }
                    repeat(columns - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}
