# Veyra maintenance rules

- Current stable Android source: `main` and `stable/0.1.6`, version 0.1.6 / code 22.
  Completed preview `preview/0.1.6-beta1` remains version 0.1.6-beta1 / code 21.
  Current preview `preview/0.1.7-beta1`, version 0.1.7-beta1 / code 25, includes Theme Studio, twenty-one published themes (the original five, six-theme reference collection, five-theme Wayfarer collection and five-theme Dreamscape collection) and optional themed launcher icons. Glass Atelier adds twelve separate launcher choices without theme bindings.
  Keep future preview features out of stable until the owner promotes them.
  Older branches retain their historical Android code and version.
- For app/version/download changes, also update and push the separate website
  repository `Bhavishyadalal/Veyra-website`. This is the owner's standing request.
  Read its `AGENTS.md`; update `src/config.js` source/checksum/change-note links,
  current version labels and any affected external links. Keep stable and preview
  distinct, verify real app branch files, and never claim an unpublished APK exists.
  Website URL: `https://veyra-website-mauve.vercel.app/`. Verify build, type checks
  and relevant mobile/desktop links before pushing; do not claim Vercel deployment
  succeeded solely because Git push succeeded.
- Canonical server source is `Bhavishyadalal/Veyra-backend` on `main`. The app's
  `backend/` is a snapshot, not a separate deployment. Read `docs/BACKEND_SYNC.md`
  and verify its manifest before backend changes. Mirror future canonical fixes
  across every maintained app branch; do not resurrect the old VM deployment.
- Official rooms, invites and presence use
  `https://veyra-listen-together.onrender.com`. Old operator hostnames in the
  retirement policy/tests must remain blocked; never turn them back into defaults.
  Preserve intentional custom servers and never forward old membership tokens to
  a replacement service. TURN credentials do not belong to this REST/WebSocket server.
- Keep only the current stable source ZIP and newest three preview source ZIPs
  in `downloads/`, with matching SHA-256 sidecars. Website source lives in the
  separate `Veyra-website` repository; do not re-add old website/media ZIPs here.
  Generate source packages with `scripts/package_source.py` after staging source
  changes. Include the backend and its manifest, omit local config/secrets/builds.
  Generated images under `themes/previews/` remain in Git and the gallery; omit
  those study renders from source ZIPs, retaining their renderer and theme assets.
- Check all remote branch heads explicitly (`git ls-remote --heads origin`). A
  restricted fetch refspec may expose only `origin/HEAD` by default.
- Archive cleanup removes files from branch tips, not Git history. Do not force
  push, rewrite history, delete tags or remove release assets without explicit scope.
- Record verification limits honestly: focused Kotlin tests and local WebSocket
  probes do not prove a full Android build, real device behavior or live Render uptime.

- Owner delegates ongoing GitHub storage housekeeping: set new Actions artifacts
  to 7-day retention, keep APKs out of Git commits, and follow the existing
  stable/preview source-ZIP cap. Preserve private signing backups outside Git.
  Prefer Release assets for published APKs. Do not delete release assets, tags,
  current user downloads, or rewrite Git history under general housekeeping.
  Retention changes affect new artifacts; do not claim old artifacts were purged
  or account-level storage was checked without direct evidence.
