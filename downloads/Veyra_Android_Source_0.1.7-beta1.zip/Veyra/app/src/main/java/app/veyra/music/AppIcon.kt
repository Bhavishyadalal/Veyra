package app.veyra.music

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

/**
 * The home-screen icon choices. Each is an `<activity-alias>` in the manifest
 * carrying the launcher intent filter; exactly one is enabled at a time.
 *
 * The glass icons are adaptive icons whose foreground already holds the finished
 * icon in its own shape (Apple squircle, Samsung squircle or Pixel circle), so
 * [previewRes] — that foreground — shows the variant as designed rather than
 * through the device's launcher mask. The first two keep yesterday's alias
 * names so a choice made before the update stays enabled.
 */
enum class AppIcon(val alias: String, val iconRes: Int, val labelRes: Int, val previewRes: Int? = null) {
    AtelierAuroraVeil("LauncherAtelierAuroraVeil", R.mipmap.ic_atelier_aurora_veil, R.string.app_icon_atelier_aurora_veil, R.mipmap.ic_atelier_aurora_veil_foreground),
    AtelierSakuraPearl("LauncherAtelierSakuraPearl", R.mipmap.ic_atelier_sakura_pearl, R.string.app_icon_atelier_sakura_pearl, R.mipmap.ic_atelier_sakura_pearl_foreground),
    AtelierObsidianGold("LauncherAtelierObsidianGold", R.mipmap.ic_atelier_obsidian_gold, R.string.app_icon_atelier_obsidian_gold, R.mipmap.ic_atelier_obsidian_gold_foreground),
    AtelierGlacierBlue("LauncherAtelierGlacierBlue", R.mipmap.ic_atelier_glacier_blue, R.string.app_icon_atelier_glacier_blue, R.mipmap.ic_atelier_glacier_blue_foreground),
    AtelierRubyVelvet("LauncherAtelierRubyVelvet", R.mipmap.ic_atelier_ruby_velvet, R.string.app_icon_atelier_ruby_velvet, R.mipmap.ic_atelier_ruby_velvet_foreground),
    AtelierEmeraldDew("LauncherAtelierEmeraldDew", R.mipmap.ic_atelier_emerald_dew, R.string.app_icon_atelier_emerald_dew, R.mipmap.ic_atelier_emerald_dew_foreground),
    AtelierLunarEclipse("LauncherAtelierLunarEclipse", R.mipmap.ic_atelier_lunar_eclipse, R.string.app_icon_atelier_lunar_eclipse, R.mipmap.ic_atelier_lunar_eclipse_foreground),
    AtelierCosmicPrism("LauncherAtelierCosmicPrism", R.mipmap.ic_atelier_cosmic_prism, R.string.app_icon_atelier_cosmic_prism, R.mipmap.ic_atelier_cosmic_prism_foreground),
    AtelierRoseQuartz("LauncherAtelierRoseQuartz", R.mipmap.ic_atelier_rose_quartz, R.string.app_icon_atelier_rose_quartz, R.mipmap.ic_atelier_rose_quartz_foreground),
    AtelierEmberForge("LauncherAtelierEmberForge", R.mipmap.ic_atelier_ember_forge, R.string.app_icon_atelier_ember_forge, R.mipmap.ic_atelier_ember_forge_foreground),
    AtelierOceanOpal("LauncherAtelierOceanOpal", R.mipmap.ic_atelier_ocean_opal, R.string.app_icon_atelier_ocean_opal, R.mipmap.ic_atelier_ocean_opal_foreground),
    AtelierRoyalSapphire("LauncherAtelierRoyalSapphire", R.mipmap.ic_atelier_royal_sapphire, R.string.app_icon_atelier_royal_sapphire, R.mipmap.ic_atelier_royal_sapphire_foreground),
    GoldenAfterglow("LauncherAfterglow", R.mipmap.ic_theme_afterglow, R.string.app_icon_afterglow, R.mipmap.ic_theme_afterglow_foreground),
    LilypondParade("LauncherLilypond", R.mipmap.ic_theme_lilypond, R.string.app_icon_lilypond, R.mipmap.ic_theme_lilypond_foreground),
    DustbyteOutpost("LauncherDustbyte", R.mipmap.ic_theme_dustbyte, R.string.app_icon_dustbyte, R.mipmap.ic_theme_dustbyte_foreground),
    AlpineEmber("LauncherAlpine", R.mipmap.ic_theme_alpine, R.string.app_icon_alpine, R.mipmap.ic_theme_alpine_foreground),
    StarfallPals("LauncherStarfall", R.mipmap.ic_theme_starfall, R.string.app_icon_starfall, R.mipmap.ic_theme_starfall_foreground),
    PumpkinPurr("LauncherPurr", R.mipmap.ic_theme_purr, R.string.app_icon_purr, R.mipmap.ic_theme_purr_foreground),
    SunsetCrew("LauncherSunset", R.mipmap.ic_theme_sunset, R.string.app_icon_sunset, R.mipmap.ic_theme_sunset_foreground),
    StarrySpirits("LauncherSpirits", R.mipmap.ic_theme_spirits, R.string.app_icon_spirits, R.mipmap.ic_theme_spirits_foreground),
    AnalogReverie("LauncherAnalog", R.mipmap.ic_theme_analog, R.string.app_icon_analog, R.mipmap.ic_theme_analog_foreground),
    PetalPromise("LauncherPetal", R.mipmap.ic_theme_petal, R.string.app_icon_petal, R.mipmap.ic_theme_petal_foreground),
    MoonlitHerbarium("LauncherHerbarium", R.mipmap.ic_theme_herbarium, R.string.app_icon_herbarium, R.mipmap.ic_theme_herbarium_foreground),
    MidnightExpress("LauncherMidnight", R.mipmap.ic_theme_midnight, R.string.app_icon_midnight, R.mipmap.ic_theme_midnight_foreground),
    AstralTide("LauncherAstral", R.mipmap.ic_theme_astral, R.string.app_icon_astral, R.mipmap.ic_theme_astral_foreground),
    PlaytimeClub("LauncherPlaytime", R.mipmap.ic_theme_playtime, R.string.app_icon_playtime, R.mipmap.ic_theme_playtime_foreground),
    WebSlinger("LauncherWebSlinger", R.mipmap.ic_theme_web, R.string.app_icon_web_slinger, R.mipmap.ic_theme_web_foreground),
    HalloweenNocturne("LauncherHalloween", R.mipmap.ic_theme_halloween, R.string.app_icon_halloween, R.mipmap.ic_theme_halloween_foreground),
    Default("LauncherDefault", R.mipmap.ic_wave_glass, R.string.app_icon_wave_default, R.mipmap.ic_wave_glass_foreground),
    WhiteFrost("LauncherWaveFrost", R.mipmap.ic_wave_frost, R.string.app_icon_wave_frost, R.mipmap.ic_wave_frost_foreground),
    GlassOrbit("LauncherWaveOrbit", R.mipmap.ic_wave_orbit, R.string.app_icon_wave_orbit, R.mipmap.ic_wave_orbit_foreground),
    Original("LauncherOriginal", R.mipmap.ic_launcher, R.string.app_icon_original),
    LiquidGlass("LauncherGlassLight", R.mipmap.ic_liquid_glass, R.string.app_icon_liquid_glass, R.mipmap.ic_liquid_glass_foreground),
    LiquidGlassDark("LauncherGlassDark", R.mipmap.ic_liquid_glass_dark, R.string.app_icon_liquid_glass_dark, R.mipmap.ic_liquid_glass_dark_foreground),
    LiquidGlassClear("LauncherGlassClear", R.mipmap.ic_liquid_glass_clear, R.string.app_icon_liquid_glass_clear, R.mipmap.ic_liquid_glass_clear_foreground),
    LiquidGlassClearDark("LauncherGlassClearDark", R.mipmap.ic_liquid_glass_clear_dark, R.string.app_icon_liquid_glass_clear_dark, R.mipmap.ic_liquid_glass_clear_dark_foreground),
    SamsungGlass("LauncherSamsungGlass", R.mipmap.ic_samsung_glass, R.string.app_icon_samsung_glass, R.mipmap.ic_samsung_glass_foreground),
    SamsungGlassDark("LauncherSamsungGlassDark", R.mipmap.ic_samsung_glass_dark, R.string.app_icon_samsung_glass_dark, R.mipmap.ic_samsung_glass_dark_foreground),
    SamsungGlassClear("LauncherSamsungGlassClear", R.mipmap.ic_samsung_glass_clear, R.string.app_icon_samsung_glass_clear, R.mipmap.ic_samsung_glass_clear_foreground),
    SamsungGlassClearDark("LauncherSamsungGlassClearDark", R.mipmap.ic_samsung_glass_clear_dark, R.string.app_icon_samsung_glass_clear_dark, R.mipmap.ic_samsung_glass_clear_dark_foreground),
    PixelGlass("LauncherPixelGlass", R.mipmap.ic_pixel_glass, R.string.app_icon_pixel_glass, R.mipmap.ic_pixel_glass_foreground),
    PixelGlassDark("LauncherPixelGlassDark", R.mipmap.ic_pixel_glass_dark, R.string.app_icon_pixel_glass_dark, R.mipmap.ic_pixel_glass_dark_foreground),
    PixelGlassClear("LauncherPixelGlassClear", R.mipmap.ic_pixel_glass_clear, R.string.app_icon_pixel_glass_clear, R.mipmap.ic_pixel_glass_clear_foreground),
    PixelGlassClearDark("LauncherPixelGlassClearDark", R.mipmap.ic_pixel_glass_clear_dark, R.string.app_icon_pixel_glass_clear_dark, R.mipmap.ic_pixel_glass_clear_dark_foreground);

    private fun component(context: Context) =
        ComponentName(context.packageName, "app.veyra.music.$alias")

    companion object {
        /** A data-only theme cannot supply a component name or an arbitrary launcher alias. */
        fun forTheme(id: String?): AppIcon? = when (id) {
            "golden-afterglow" -> GoldenAfterglow
            "lilypond-parade" -> LilypondParade
            "dustbyte-outpost" -> DustbyteOutpost
            "alpine-ember" -> AlpineEmber
            "starfall-pals" -> StarfallPals
            "pumpkin-purr" -> PumpkinPurr
            "sunset-crew" -> SunsetCrew
            "starry-spirits" -> StarrySpirits
            "analog-reverie" -> AnalogReverie
            "petal-promise" -> PetalPromise
            "moonlit-herbarium" -> MoonlitHerbarium
            "midnight-express" -> MidnightExpress
            "astral-tide" -> AstralTide
            "playtime-club" -> PlaytimeClub
            "web-slinger" -> WebSlinger
            "halloween-nocturne" -> HalloweenNocturne
            else -> null
        }

        @Synchronized
        fun current(context: Context): AppIcon {
            val pm = context.packageManager
            return entries.firstOrNull {
                val state = pm.getComponentEnabledSetting(it.component(context))
                state == PackageManager.COMPONENT_ENABLED_STATE_ENABLED ||
                    (state == PackageManager.COMPONENT_ENABLED_STATE_DEFAULT && it == Default)
            } ?: Default
        }

        /** Atomic on Android 13+, and enable-first on older Android versions. */
        @Synchronized
        fun apply(context: Context, icon: AppIcon) {
            val pm = context.packageManager
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                pm.setComponentEnabledSettings(entries.map {
                    PackageManager.ComponentEnabledSetting(
                        it.component(context),
                        if (it == icon) PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                        else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        PackageManager.DONT_KILL_APP,
                    )
                })
            } else {
                val previous = current(context)
                try {
                    pm.setComponentEnabledSetting(icon.component(context), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
                    entries.filter { it != icon }.forEach {
                        pm.setComponentEnabledSetting(it.component(context), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
                    }
                } catch (error: Exception) {
                    // Best effort rollback, with the previously working launcher enabled first.
                    runCatching { pm.setComponentEnabledSetting(previous.component(context), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP) }
                    if (icon != previous) runCatching { pm.setComponentEnabledSetting(icon.component(context), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP) }
                    throw error
                }
            }
        }
    }
}
