export function initNavigation() {
  const toggle = document.querySelector("#menu-toggle");
  const nav = document.querySelector("#mobile-nav");
  if (!toggle || !nav) return;
  const links = [...nav.querySelectorAll("a")];
  function setOpen(open, returnFocus = false) {
    nav.hidden = !open;
    toggle.setAttribute("aria-expanded", String(open));
    toggle.setAttribute(
      "aria-label",
      open ? "Close navigation" : "Open navigation",
    );
    document.body.classList.toggle("menu-open", open);
    if (open) links[0]?.focus();
    else if (returnFocus) toggle.focus();
  }
  toggle.addEventListener("click", () => setOpen(nav.hidden));
  links.forEach((link) => link.addEventListener("click", () => setOpen(false)));
  document.addEventListener("keydown", (event) => {
    if (nav.hidden) return;
    if (event.key === "Escape") {
      setOpen(false, true);
      return;
    }
    if (event.key !== "Tab") return;
    const focusable = [toggle, ...links];
    const index = focusable.indexOf(document.activeElement);
    if (event.shiftKey && index <= 0) {
      event.preventDefault();
      links.at(-1)?.focus();
    } else if (!event.shiftKey && index === focusable.length - 1) {
      event.preventDefault();
      toggle.focus();
    }
  });
  document.addEventListener("click", (event) => {
    if (!nav.hidden && !event.target.closest(".site-header")) setOpen(false);
  });
  window
    .matchMedia("(min-width: 901px)")
    .addEventListener("change", (event) => {
      if (event.matches && !nav.hidden) setOpen(false);
    });
}
