import "./styles/base.css";
import "./styles/layout.css";
import "./styles/preview.css";
import "./styles/motion.css";
import { siteConfig } from "./config.js";
import { initMotion, initIntro, initScrollProgress } from "./motion.js";
import { initNavigation } from "./navigation.js";
import { initShowcase } from "./showcase.js";
import { initConstellation } from "./constellation.js";

// Each enhancement is isolated: a missing canvas, storage API or preview never hides core content.
initMotion();
initNavigation();
initShowcase();
initIntro();
initScrollProgress();
initConstellation();
document.querySelectorAll("[data-link]").forEach((link) => {
  const url = siteConfig[link.dataset.link];
  if (url) link.href = url;
});
document.querySelector("#year").textContent = String(new Date().getFullYear());
