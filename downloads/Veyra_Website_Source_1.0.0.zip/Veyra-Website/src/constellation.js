import { motion } from "./motion.js";

/** A small canvas confined to the hero. No WebGL, shader, texture or continuous offscreen work. */
export function initConstellation() {
  const canvas = document.querySelector("#constellation");
  const hero = document.querySelector(".hero");
  const art = document.querySelector(".hero__art");
  const context = canvas?.getContext("2d");
  if (!context || !hero) return;
  const finePointer = matchMedia("(hover: hover) and (pointer: fine)");
  let frame = 0;
  let inView = true;
  let width = 0;
  let height = 0;
  let lastDraw = 0;
  let start = performance.now();
  let bounds = hero.getBoundingClientRect();
  // Deterministic positions avoid layout-dependent randomness or hydration-like flashes.
  const stars = Array.from({ length: 44 }, (_, index) => ({
    x: ((index * 73 + 37) % 997) / 997,
    y: ((index * 137 + 19) % 991) / 991,
    radius: 0.45 + (index % 3) * 0.3,
    phase: index * 1.7,
  }));
  function draw(time = start) {
    context.clearRect(0, 0, width, height);
    const phase =
      motion.reduced || !finePointer.matches ? 0 : (time - start) / 18000;
    stars.forEach((star) => {
      const x = star.x * width;
      const y = star.y * height;
      const alpha = 0.16 + (Math.sin(phase + star.phase) + 1) * 0.13;
      context.fillStyle = `rgba(203,178,251,${alpha})`;
      context.beginPath();
      context.arc(x, y, star.radius, 0, Math.PI * 2);
      context.fill();
    });
  }
  function tick(time) {
    frame = 0;
    if (!inView || document.hidden || motion.reduced || !finePointer.matches)
      return;
    if (time - lastDraw > 50) {
      draw(time);
      lastDraw = time;
    }
    frame = requestAnimationFrame(tick);
  }
  function sync() {
    cancelAnimationFrame(frame);
    frame = 0;
    art?.style.removeProperty("--art-x");
    art?.style.removeProperty("--art-y");
    draw();
    if (inView && !document.hidden && !motion.reduced && finePointer.matches)
      frame = requestAnimationFrame(tick);
  }
  function resize() {
    bounds = hero.getBoundingClientRect();
    width = hero.clientWidth;
    height = hero.clientHeight;
    const pixelRatio = Math.min(devicePixelRatio || 1, 1.75);
    canvas.width = Math.round(width * pixelRatio);
    canvas.height = Math.round(height * pixelRatio);
    context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    draw();
  }
  const observer = new ResizeObserver(resize);
  observer.observe(hero);
  if ("IntersectionObserver" in window)
    new IntersectionObserver((entries) => {
      inView = entries[0].isIntersecting;
      if (inView) bounds = hero.getBoundingClientRect();
      sync();
    }).observe(hero);
  document.addEventListener("visibilitychange", sync);
  finePointer.addEventListener("change", sync);
  motion.subscribe(sync);
  let pointerFrame = 0;
  let pointerX = 0;
  let pointerY = 0;
  hero.addEventListener(
    "pointermove",
    (event) => {
      if (motion.reduced || !finePointer.matches || !inView) return;
      bounds = hero.getBoundingClientRect();
      pointerX = ((event.clientX - bounds.left) / bounds.width - 0.5) * 12;
      pointerY = ((event.clientY - bounds.top) / bounds.height - 0.5) * 12;
      if (!pointerFrame)
        pointerFrame = requestAnimationFrame(() => {
          art.style.setProperty("--art-x", `${pointerX.toFixed(1)}px`);
          art.style.setProperty("--art-y", `${pointerY.toFixed(1)}px`);
          pointerFrame = 0;
        });
    },
    { passive: true },
  );
  hero.addEventListener("pointerleave", () => {
    cancelAnimationFrame(pointerFrame);
    pointerFrame = 0;
    art?.style.removeProperty("--art-x");
    art?.style.removeProperty("--art-y");
  });
  resize();
  sync();
}
