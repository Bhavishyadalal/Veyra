const storageKey = "veyra-site-motion";
const systemPreference = window.matchMedia("(prefers-reduced-motion: reduce)");
const subscribers = new Set();
let explicitChoice;
try {
  explicitChoice = localStorage.getItem(storageKey);
} catch {
  /* Storage is optional. */
}
let reduced =
  explicitChoice === "reduced" ||
  (explicitChoice !== "full" && systemPreference.matches);

export const motion = {
  get reduced() {
    return reduced;
  },
  subscribe(callback) {
    subscribers.add(callback);
    return () => subscribers.delete(callback);
  },
};

function applyPreference() {
  document.documentElement.dataset.motion = reduced ? "reduced" : "full";
  const button = document.querySelector("#motion-toggle");
  if (button) {
    button.setAttribute("aria-pressed", String(reduced));
    button.setAttribute(
      "aria-label",
      reduced ? "Enable website motion" : "Reduce website motion",
    );
    button.querySelector(".motion-label").textContent = reduced
      ? "Motion off"
      : "Motion on";
  }
  subscribers.forEach((callback) => callback(reduced));
}

export function initMotion() {
  applyPreference();
  document.querySelector("#motion-toggle")?.addEventListener("click", () => {
    reduced = !reduced;
    explicitChoice = reduced ? "reduced" : "full";
    try {
      localStorage.setItem(storageKey, explicitChoice);
    } catch {
      /* Private browsing can deny storage. */
    }
    applyPreference();
  });
  systemPreference.addEventListener("change", (event) => {
    if (explicitChoice !== "full" && explicitChoice !== "reduced") {
      reduced = event.matches;
      applyPreference();
    }
  });
  const items = document.querySelectorAll(".reveal");
  if (!("IntersectionObserver" in window)) {
    items.forEach((item) => item.classList.add("is-visible"));
    return;
  }
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { rootMargin: "0px 0px -30px 0px", threshold: 0.06 },
  );
  items.forEach((item) => observer.observe(item));
}

export function initIntro() {
  const element = document.querySelector("#intro");
  if (!element || reduced || location.hash) return;
  try {
    if (sessionStorage.getItem("veyra-intro-seen")) return;
    sessionStorage.setItem("veyra-intro-seen", "yes");
  } catch {
    /* Intro still works without storage. */
  }
  element.hidden = false;
  let closeTimer;
  let hideTimer;
  function dismiss(immediate = false) {
    clearTimeout(closeTimer);
    clearTimeout(hideTimer);
    element.classList.add("is-closing");
    if (immediate || reduced) element.hidden = true;
    else
      hideTimer = window.setTimeout(() => {
        element.hidden = true;
      }, 900);
  }
  closeTimer = window.setTimeout(() => dismiss(), 450);
  element.querySelector("#skip-intro").addEventListener("click", () => {
    dismiss(true);
    document.querySelector(".hero__actions a")?.focus({ preventScroll: true });
  });
  motion.subscribe((isReduced) => {
    if (isReduced) dismiss(true);
  });
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) dismiss(true);
  });
}

export function initScrollProgress() {
  let pending = false;
  function update() {
    const distance = document.documentElement.scrollHeight - window.innerHeight;
    const fraction =
      distance > 0 ? Math.min(1, Math.max(0, window.scrollY / distance)) : 0;
    document.documentElement.style.setProperty(
      "--page-progress",
      fraction.toFixed(4),
    );
    document
      .querySelector("#site-header")
      ?.classList.toggle("is-scrolled", window.scrollY > 35);
    pending = false;
  }
  function schedule() {
    if (pending) return;
    pending = true;
    requestAnimationFrame(update);
  }
  window.addEventListener("scroll", schedule, { passive: true });
  window.addEventListener("resize", schedule, { passive: true });
  update();
}
