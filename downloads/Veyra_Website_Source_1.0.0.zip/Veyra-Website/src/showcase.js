import { motion } from "./motion.js";

const artwork = (name) => `${import.meta.env.BASE_URL}artwork/${name}.svg`;
const icon = (name, classes = "") =>
  `<svg class="icon ${classes}" aria-hidden="true"><use href="#icon-${name}"/></svg>`;
const tracks = [
  {
    title: "Nocturne",
    artist: "The quiet hours",
    artwork: "nocturne",
    duration: 212,
  },
  {
    title: "Slow Bloom",
    artist: "Room for a little light",
    artwork: "bloom",
    duration: 184,
  },
  {
    title: "After Orbit",
    artist: "Somewhere past midnight",
    artwork: "orbit",
    duration: 236,
  },
];
const captions = {
  discover: "A whole world. One home.",
  player: "Nothing between you and the song.",
  library: "All your favorites. All in one place.",
};
const formatTime = (seconds) =>
  `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, "0")}`;

export function initShowcase() {
  const container = document.querySelector("#phone-content");
  if (!container) return;
  const panel = document.querySelector("#scene-panel");
  const phone = document.querySelector("#phone");
  const tabs = [...document.querySelectorAll("[data-scene]")];
  let scene = "discover";
  let trackIndex = 0;
  let playing = false;
  let progress = 74;
  let frame = 0;
  let previousTime = 0;
  let inView = false;
  let lastSecond = -1;
  const liked = new Set();
  const status = document.createElement("p");
  status.className = "scene-status";
  status.setAttribute("aria-live", "polite");
  panel.append(status);

  function discoverMarkup() {
    return `<div class="preview-brand"><img src="${import.meta.env.BASE_URL}brand/favicon.png" width="29" height="29" alt=""/><span class="wordmark">Veyra</span></div>
      <h3 class="preview-greeting">Find your next favorite.</h3><p class="preview-muted">A little closer to your kind of music.</p>
      <div class="preview-shelf-heading">For the quiet hours <span>A mood, a moment ↗</span></div>
      <div class="preview-banner"><img src="${artwork("nocturne")}" width="600" height="600" alt="Illustrated violet crescent moon"/><div class="preview-banner__caption"><small>AFTER DARK / A VISUAL MIX</small><strong>Nocturne</strong></div><span class="preview-banner__play" aria-hidden="true">${icon("play")}</span></div>
      <div class="preview-shelf-heading">A different direction <span>Keep exploring</span></div>
      <div class="preview-albums"><div class="preview-album"><img src="${artwork("bloom")}" width="600" height="600" alt="Illustrated green flower"/><strong>Slow Bloom</strong><small>A softer kind of Sunday</small></div><div class="preview-album"><img src="${artwork("orbit")}" width="600" height="600" alt="Illustrated ringed orange planet"/><strong>After Orbit</strong><small>Take the long way home</small></div></div>
      <div class="preview-mini"><img src="${artwork("nocturne")}" width="30" height="30" alt=""/><span><strong>Nocturne</strong><small>The quiet hours</small></span>${icon("play")}</div>`;
  }

  function playerMarkup() {
    const track = tracks[trackIndex];
    return `<div class="preview-player-header"><span>⌄</span><span>YOUR QUIET CORNER</span><span>···</span></div>
      <img class="preview-player-cover" src="${artwork(track.artwork)}" width="600" height="600" alt="${track.title} illustrative cover artwork"/>
      <div class="preview-player-credits"><div><h3>${track.title}</h3><p>${track.artist}</p></div><button class="demo-like" data-action="like" aria-label="Like this illustrative track" aria-pressed="${liked.has(trackIndex)}">${icon("heart")}</button></div>
      <div class="demo-progress" role="progressbar" aria-label="Visual track progress" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round((progress / track.duration) * 100)}"><div class="demo-progress__fill" style="transform:scaleX(${progress / track.duration})"></div></div>
      <div class="preview-times"><span id="demo-elapsed">${formatTime(progress)}</span><span>−${formatTime(track.duration - progress)}</span></div>
      <div class="preview-transport"><button class="demo-previous" data-action="previous" aria-label="Previous illustrative track">${icon("next")}</button><button class="demo-play" data-action="play" aria-label="${playing ? "Pause" : "Start"} visual playback preview" aria-pressed="${playing}">${icon(playing ? "pause" : "play")}</button><button data-action="next" aria-label="Next illustrative track">${icon("next")}</button></div>
      <div class="demo-track-picker" aria-label="Illustrative tracks">${tracks.map((item, index) => `<button data-track="${index}" aria-pressed="${index === trackIndex}" aria-label="Preview ${item.title}"><img src="${artwork(item.artwork)}" width="30" height="30" alt=""/></button>`).join("")}</div>
      <p class="preview-player-note">VISUAL DEMO ONLY · NO AUDIO</p>`;
  }

  function libraryMarkup() {
    return `<div class="preview-library-top"><h3>Your library.</h3>${icon("library")}</div><p class="preview-muted">The songs that feel like somewhere.</p><div class="preview-chips" aria-hidden="true"><span>Playlists</span><span>Albums</span><span>Artists</span></div>
      <div class="preview-library-covers"><div class="favorite-art">${icon("heart")}<strong>Liked songs</strong></div><div><img src="${artwork("nocturne")}" width="600" height="600" alt=""/><strong>After hours</strong></div><div><img src="${artwork("bloom")}" width="600" height="600" alt=""/><strong>Slow Sundays</strong></div><div><img src="${artwork("orbit")}" width="600" height="600" alt=""/><strong>Away from here</strong></div></div>
      <div class="preview-shelf-heading">Always close</div><div class="preview-library-row">${icon("download")}<span><strong>Downloads</strong><small>Ready for the long way home</small></span><span>↗</span></div><div class="preview-library-row">${icon("headphones")}<span><strong>Local music</strong><small>A place for your own collection</small></span><span>↗</span></div>`;
  }

  function render(announce = false) {
    container.innerHTML =
      scene === "discover"
        ? discoverMarkup()
        : scene === "player"
          ? playerMarkup()
          : libraryMarkup();
    panel.setAttribute("aria-labelledby", `tab-${scene}`);
    document.querySelector("#scene-caption").textContent = captions[scene];
    document.querySelector("#scene-counter").textContent =
      `0${tabs.findIndex((tab) => tab.dataset.scene === scene) + 1} — 03`;
    tabs.forEach((tab) => {
      const active = tab.dataset.scene === scene;
      tab.classList.toggle("is-active", active);
      tab.setAttribute("aria-selected", String(active));
      tab.tabIndex = active ? 0 : -1;
    });
    document
      .querySelectorAll(".phone__nav>span")
      .forEach((item, index) =>
        item.classList.toggle(
          "is-current",
          scene === "library" ? index === 3 : index === 0,
        ),
      );
    phone.classList.remove("is-switching");
    if (!motion.reduced) {
      void phone.offsetWidth;
      phone.classList.add("is-switching");
    }
    if (announce)
      status.textContent =
        scene === "player"
          ? `${tracks[trackIndex].title}. Visual demo only; no audio.`
          : captions[scene];
    previousTime = 0;
    syncPlayback();
  }

  function updateProgress() {
    const track = tracks[trackIndex];
    const fraction = Math.min(1, progress / track.duration);
    const bar = container.querySelector(".demo-progress");
    if (!bar) return;
    bar.querySelector(".demo-progress__fill").style.transform =
      `scaleX(${fraction})`;
    const second = Math.floor(progress);
    if (second !== lastSecond) {
      lastSecond = second;
      bar.setAttribute("aria-valuenow", String(Math.round(fraction * 100)));
      container.querySelector("#demo-elapsed").textContent =
        formatTime(progress);
      container.querySelector(".preview-times span:last-child").textContent =
        `−${formatTime(track.duration - progress)}`;
    }
  }

  function animate(time) {
    frame = 0;
    if (
      !playing ||
      scene !== "player" ||
      !inView ||
      document.hidden ||
      motion.reduced
    )
      return;
    if (previousTime) progress += Math.min((time - previousTime) / 1000, 0.1);
    previousTime = time;
    if (progress >= tracks[trackIndex].duration) {
      playing = false;
      progress = 0;
      render();
      return;
    }
    updateProgress();
    frame = requestAnimationFrame(animate);
  }

  function syncPlayback() {
    cancelAnimationFrame(frame);
    frame = 0;
    previousTime = 0;
    if (
      playing &&
      scene === "player" &&
      inView &&
      !document.hidden &&
      !motion.reduced
    )
      frame = requestAnimationFrame(animate);
  }

  tabs.forEach((tab, index) => {
    tab.addEventListener("click", () => {
      scene = tab.dataset.scene;
      render(true);
    });
    tab.addEventListener("keydown", (event) => {
      let next;
      if (event.key === "ArrowDown" || event.key === "ArrowRight")
        next = (index + 1) % tabs.length;
      if (event.key === "ArrowUp" || event.key === "ArrowLeft")
        next = (index - 1 + tabs.length) % tabs.length;
      if (event.key === "Home") next = 0;
      if (event.key === "End") next = tabs.length - 1;
      if (next === undefined) return;
      event.preventDefault();
      tabs[next].focus();
      tabs[next].click();
    });
  });
  container.addEventListener("click", (event) => {
    const button = event.target.closest("button");
    if (!button || scene !== "player") return;
    if (button.dataset.action === "play") {
      playing = !playing;
      button.innerHTML = icon(playing ? "pause" : "play");
      button.setAttribute("aria-pressed", String(playing));
      button.setAttribute(
        "aria-label",
        `${playing ? "Pause" : "Start"} visual playback preview`,
      );
      status.textContent = playing
        ? `Visual playback preview started${motion.reduced ? "; animation disabled" : ""}. No audio.`
        : "Visual playback preview paused.";
      syncPlayback();
      return;
    }
    if (button.dataset.action === "like") {
      if (liked.has(trackIndex)) liked.delete(trackIndex);
      else liked.add(trackIndex);
      button.setAttribute("aria-pressed", String(liked.has(trackIndex)));
      status.textContent = liked.has(trackIndex)
        ? "Illustrative track liked in this website preview."
        : "Illustrative track unliked.";
      return;
    }
    if ("track" in button.dataset) trackIndex = Number(button.dataset.track);
    else
      trackIndex =
        (trackIndex +
          (button.dataset.action === "previous" ? -1 : 1) +
          tracks.length) %
        tracks.length;
    progress = 0;
    lastSecond = -1;
    const focusSelector =
      "track" in button.dataset
        ? `[data-track="${trackIndex}"]`
        : `[data-action="${button.dataset.action}"]`;
    render(true);
    container.querySelector(focusSelector)?.focus({ preventScroll: true });
  });
  if ("IntersectionObserver" in window)
    new IntersectionObserver(
      (entries) => {
        inView = entries[0].isIntersecting;
        syncPlayback();
      },
      { threshold: 0.1 },
    ).observe(panel);
  else inView = true;
  document.addEventListener("visibilitychange", syncPlayback);
  motion.subscribe(syncPlayback);
  render();
}
