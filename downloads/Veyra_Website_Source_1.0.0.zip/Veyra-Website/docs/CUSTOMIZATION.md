# Make the showcase yours

## Content and links

`index.html` contains real semantic content. Keep the main headline to a similar length when changing it, and check the 320px layout afterward. Use the existing heading levels (one h1, sections h2, features h3).

`src/config.js` holds the Android repository, releases and source ZIP URLs. Static HTML also contains those destinations so downloads work without JavaScript. When releasing another Android version, change both locations and the version text in the FAQ/download section. Link a real APK only when one has actually been published; label it separately from source code.

The app repository remains Bhavishyadalal/Veyra. This package is intended for a separate website repository. No files need to be copied into the Android app project.

## Effects map

| Effect           | Files                                   | Behavior                                                                          |
| ---------------- | --------------------------------------- | --------------------------------------------------------------------------------- |
| Opening curtains | `motion.js`, `styles/motion.css`        | One short, skippable introduction per tab session.                                |
| Starfield        | `constellation.js`                      | Hero-only canvas; static on touch/reduced motion; stops when hidden/offscreen.    |
| Icon movement    | `constellation.js`, `styles/layout.css` | Small pointer movement only for fine-pointer devices.                             |
| Scroll progress  | `motion.js`                             | Passive scroll listener, one pending animation frame.                             |
| Section reveals  | `motion.js`, `styles/motion.css`        | IntersectionObserver; content is visible without JavaScript or in reduced motion. |
| Preview scenes   | `showcase.js`, `styles/preview.css`     | Real keyboard/touch controls, retained demo track/like state.                     |
| Visual progress  | `showcase.js`                           | Only active when playing, visible and motion is enabled; no sound.                |
| FAQ              | `index.html`, `styles/layout.css`       | Native details/summary, functional without JavaScript.                            |

The site does not alter wheel/touch scrolling, use scroll-jacking or replace native browser navigation. Avoid adding large animated blur filters, unbounded particles or third-party tracking widgets.

## Brand assets

The hero uses the actual transparent default waveform adaptive foreground; the small icon is the corresponding launcher bitmap. Preserve their aspect ratio. The Super Malibu WOFF2 subset contains only the Veyra wordmark letters, so it is unsuitable for arbitrary headings. Manrope covers the website’s Latin interface text.

All cover illustrations in `public/artwork` were made for the website. If you replace them with real album art or app screenshots, obtain the appropriate rights and change captions/alt text truthfully. Do not relabel the illustrative preview as an actual Android screenshot.

## Before public deployment

- Set your final domain in canonical/social metadata if needed.
- Recheck source/download URLs and Android version labels.
- Update the hosting/privacy description if you add analytics, forms or other services.
- Build and run browser tests.
- Test the final Vercel URL on at least one real Android phone and a desktop browser; include Safari/iOS if supporting that audience.
- Keep the font/provenance files, Manrope licence and GPL/upstream notices.
- Do not add keys or private files to the public repository. This static site requires none.
