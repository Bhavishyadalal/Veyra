# Website validation — 18 October 2026

## Actual environment and results

- Node.js **24.19.0**, npm **11.9.0**, Vite **8.3.4**.
- Clean package check: extracted the delivery ZIP into a fresh directory; `npm ci`, `npm run build` and `npm run dev` all passed. A real browser loaded the development server and interactive player without runtime errors.
- Production multi-page build: **passed**; outputs index.html, privacy.html, credits.html and local assets.
- Playwright **1.64.1**, Linux Chromium **154.0.8037.57**.
- **23 browser tests passed, zero failed, one intentionally skipped**. The skip is the mobile-only menu test in the desktop project; the mobile equivalent passed.
- Profiles: desktop 1440×1000 and a touch/mobile Chromium profile at 390×844. Additional horizontal-overflow checks cover **320, 360, 390, 768, 1024, 1440 and 1920px** widths.
- Automated axe-core WCAG A/AA checks: **no violations in the tested landing, visual-player, privacy and credits states**. This is not a complete accessibility certification.
- Tested native FAQ expansion, keyboard scene navigation, scene/track/like state, visual play/pause, mobile menu focus/Escape/anchor closing, source-download destinations, unique anchor targets, Get Veyra scrolling, reduced motion and stored preference, intro settlement/session suppression, no-JavaScript content, supporting pages, local image/font loads, browser errors and absence of external runtime requests.
- Actual browser screenshots are included in this directory. They show this website. The phone-shaped visual preview is illustrative and is not an Android app screenshot.

The preview uses no audio/video element and makes no streaming request. Its play button only drives the labeled visual demo. Download links point to the existing Android source ZIP and GitHub Releases; tests verify the configured destinations rather than downloading/validating an APK.

## Bundle observations

The production landing JavaScript is about **13.4 kB uncompressed / 4.8 kB gzip**, plus a small shared module. No runtime UI framework or animation package is installed. Local WOFF2 font subsets total about **50.5 kB**. The hero uses the existing transparent adaptive foreground (about **108 kB**) rather than the 1.7 MB design bitmap. These are build/asset observations, not measured user-device speed or FPS claims.

Canvas resolution and draw frequency are bounded. Its continuous work stops while hidden/offscreen or reduced motion is enabled; touch devices receive a static starfield. The visual progress loop runs only while explicitly started, visible and allowed by motion settings. Scroll/reveal behavior uses passive listeners and IntersectionObserver without scroll-jacking.

## Scope and remaining checks

No GitHub push, repository creation, Vercel deployment, Android change or APK build was performed for this standalone website delivery.

The site was inspected in desktop and mobile **emulation**, not on a physical phone. Firefox, Safari/iOS and an actual Windows PC were not executed here. Test those and the final hosted Vercel URL before a public launch. Real-device performance, hosting/network latency and a production domain’s social previews are unmeasured. The package includes Vercel configuration but no live deployment is claimed.

The animated repository SVG has a static fallback. Its animation depends on the image renderer and reduced-motion preferences; GitHub READMEs do not execute this website’s CSS or JavaScript.
