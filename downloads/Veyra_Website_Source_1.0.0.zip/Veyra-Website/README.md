<div align="center">

<img src="docs/repository-banner.svg" alt="Veyra — Lose the noise. Find your frequency." width="100%" />

# Veyra · The showcase

**A little mystery. A lot of music.**

An atmospheric website for the Veyra Android music player. Split-opening reveal, a quiet constellation, scroll-driven chapters and an interactive visual listening preview. Made for desktop and mobile.

[Preview locally](#preview-on-your-pc) · [The experience](#the-experience) · [Deploy on Vercel](#deploy-on-vercel) · [Android app source](https://github.com/Bhavishyadalal/Veyra)

`Vite 8` · `Vanilla JavaScript` · `Local fonts & assets` · `Responsive` · `Reduced motion` · `No analytics`

</div>

---

## Preview on your PC

Install **Node.js 22.12 or newer** (Node 24 LTS is recommended). Extract the whole ZIP, open a terminal inside `Veyra-Website`, then run:

```sh
npm install
npm run dev
```

Open the address printed in the terminal, normally **http://localhost:5173**. Keep the terminal open while previewing. Press **Ctrl+C** to stop.

On Windows, you can open the extracted folder in File Explorer, type `cmd` into its address bar and press Enter to open the terminal in the right place. Do not double-click `index.html`; this project uses JavaScript modules and Vite.

To preview the production build:

```sh
npm run build
npm run preview
```

The production preview normally uses **http://localhost:4173**.

## The experience

| Chapter              | What visitors can do                                                                                    |
| -------------------- | ------------------------------------------------------------------------------------------------------- |
| The opening          | See a brief split-curtain reveal; skip it immediately. It runs once per tab session.                    |
| Find your frequency  | Explore the actual glass waveform branding with a restrained, pointer-responsive hero.                  |
| Your world. On play. | Switch between Discover, Player and Library previews with mouse, touch or keyboard.                     |
| Visual player        | Select illustrative tracks, start/pause visual progress, skip and like tracks. **No audio plays.**      |
| Inside Veyra         | Discover lyrics, shared listening, offline music and source options through illustrated feature panels. |
| The details          | Scroll through the app’s welcome, interface, motion and open-source story.                              |
| Good to know         | Expand honest answers about the app, Android support, accounts and downloads.                           |
| Get Veyra            | Open the real Android source ZIP and GitHub Releases. Source ZIPs are clearly distinguished from APKs.  |

This is a **showcase website**, not a streaming client or a rewrite of the Android app. The listening preview and its original artwork are illustrative, not app screenshots. The website uses the actual app icon and a subset of the supplied Super Malibu font for the Veyra wordmark. Manrope is used for readable interface text.

## Screenshots

These are actual browser captures of this website, not Android app screenshots:

![Veyra website on a desktop browser](docs/preview-desktop.png)

![Interactive Veyra website preview section](docs/preview-experience.png)

<details>
<summary>See the mobile website</summary>

<img src="docs/preview-mobile.png" width="390" alt="Veyra website in a mobile browser viewport" />

<img src="docs/preview-mobile-experience.png" width="390" alt="The interactive experience section in a mobile website viewport" />

</details>

## Project structure

```text
Veyra-Website/
├── index.html                # Semantic landing page, readable without JavaScript
├── privacy.html              # Website privacy details
├── credits.html              # Artwork, font and project attribution
├── package.json
├── package-lock.json         # Reproducible dependency versions
├── vite.config.js            # Multi-page production build
├── vercel.json               # Vercel settings and basic response headers
├── src/
│   ├── main.js               # Landing page entry
│   ├── document.js           # Shared styling for supporting pages
│   ├── config.js             # App repository, release and source ZIP links
│   ├── motion.js             # Intro, reveal observer, motion preference, scroll progress
│   ├── navigation.js         # Mobile navigation and keyboard behavior
│   ├── constellation.js      # Scoped hero canvas and pointer movement
│   ├── showcase.js           # Interactive visual preview and local demo state
│   └── styles/               # Base, layout, preview and motion styles
├── public/
│   ├── artwork/              # Three original SVG cover illustrations
│   ├── brand/                # Actual Veyra waveform assets
│   └── fonts/                # Local WOFF2 subsets and Manrope licence
├── tests/                    # Browser and accessibility regression checks
├── docs/                     # Captures, validation, customization and provenance
├── .github/workflows/        # Website CI only; no automatic deployment
├── LICENSE
└── NOTICE
```

## Motion and performance

There is no runtime framework, third-party animation package, video background, external font CDN or analytics script. The hero canvas is small, caps its resolution and redraw frequency, and stops when offscreen, hidden or reduced motion is enabled. Touch devices receive a static starfield instead of pointer effects. The visual player animates only while explicitly started, visible and allowed by motion preferences.

The site follows the system’s motion preference on first visit. The **Motion on/off** control can override it and stores that choice locally. Intro, reveals and interactions remain usable without effects. Reveal content defaults to visible when JavaScript is disabled.

These choices bound unnecessary work; they are not a guarantee of frame rate on every phone. See [validation notes](docs/VALIDATION.md) for actual checks and remaining limits.

## Customize it

- Edit headings, feature copy, FAQ and download labels in `index.html`.
- Update the real app URLs in `src/config.js`. Keep the static links and version text in `index.html` in sync so they still work without JavaScript.
- Change colors, type scale, spacing and breakpoints in `src/styles/`.
- Edit the three illustrative tracks in `src/showcase.js`.
- Replace illustrations in `public/artwork/`; retain attribution for anything you add.
- Add an absolute canonical URL and social sharing image URL after choosing your public domain. No placeholder domain is baked into this preview.

See [CUSTOMIZATION.md](docs/CUSTOMIZATION.md) for the effect map and release checklist.

## Deploy on Vercel

After you approve the local preview:

1. Create a **new, empty GitHub repository for this website**.
2. Upload the **contents** of `Veyra-Website` to its root, including the hidden `.github` folder, `package.json`, lockfile and `vercel.json`. Do not upload `node_modules` or `dist`.
3. In Vercel, choose **Add New → Project** and import the new repository.
4. Framework preset: **Vite**. Root directory: **the repository root**. Install: `npm ci`. Build: `npm run build`. Output: `dist`. Use Node 24 (or a supported Node version ≥22.12).
5. Deploy. The static site needs **no environment variables or secrets**.
6. Open the deployment URL and verify the landing page, `/privacy.html`, `/credits.html`, images and download links. Add a custom domain when ready.

`vercel.json` includes the build/output settings and basic security headers. No SPA rewrite is required because all three pages are real HTML outputs. The included GitHub workflow builds and tests; it does not deploy or change your Android repository.

## Development checks

```sh
npm ci
npm run build
npx playwright install chromium
npm test
```

Playwright tests run against the built site, with desktop and mobile Chromium profiles. The suite checks navigation, keyboard tabs, FAQ, visual player controls, real configured link destinations, local asset failures, browser errors, reduced motion, intro behavior, narrow layouts, supporting pages, no-JavaScript content and automated WCAG A/AA rules. Automated accessibility checks do not replace a manual accessibility review.

## Licence & attribution

The project retains [GPL-3.0](LICENSE) and the upstream [NOTICE](NOTICE). Manrope uses the included [SIL OFL](public/fonts/Manrope-OFL.txt). Super Malibu was supplied by the Veyra owner, who confirmed permission for embedding and public source redistribution; see its [provenance note](docs/Super-Malibu-Provenance.md). That note is not an upstream font licence or a grant of broader rights.

The site has no affiliation with music-service operators. Online app features depend on their respective providers. The website privacy notice describes the website, not the Android app.

---

<div align="center"><strong>Veyra</strong><br><sub>On your wavelength.</sub></div>
