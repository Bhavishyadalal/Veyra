import { test, expect } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";

async function openSite(page, reduced = true) {
  await page.emulateMedia({
    reducedMotion: reduced ? "reduce" : "no-preference",
  });
  await page.goto("/");
  await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
  await expect(page.locator(".preview-greeting")).toBeVisible();
}

test("local assets load, real download links work as destinations, and the page has no runtime errors", async ({
  page,
}) => {
  const errors = [];
  const requests = [];
  const failedAssets = [];
  page.on("pageerror", (error) => errors.push(error.message));
  page.on("request", (request) => requests.push(request.url()));
  page.on("response", (response) => {
    if (
      response.url().startsWith("http://127.0.0.1:4173") &&
      response.status() >= 400
    )
      failedAssets.push(response.url());
  });
  await openSite(page);
  await page.evaluate(() => document.fonts.ready);
  const downloads = page.getByRole("link", { name: "Download source ZIP" });
  await expect(downloads).toHaveAttribute(
    "href",
    /Veyra_Android_Source_0\.1\.1_Stable\.zip$/,
  );
  await expect(page.getByText("Interactive website preview.")).toBeVisible();
  expect(
    await page.evaluate(() =>
      [...document.images]
        .filter((image) => image.complete && image.naturalWidth === 0)
        .map((image) => image.src),
    ),
  ).toEqual([]);
  expect(errors).toEqual([]);
  expect(failedAssets).toEqual([]);
  expect(
    requests.filter((url) => !url.startsWith("http://127.0.0.1:4173")),
  ).toEqual([]);
});

test("preview tabs, visual player controls and track selection retain a coherent state", async ({
  page,
}) => {
  await openSite(page);
  const tab = page.getByRole("tab", { name: /Give the song its space/ });
  await tab.click();
  await expect(tab).toHaveAttribute("aria-selected", "true");
  await expect(page.locator(".preview-player-credits h3")).toHaveText(
    "Nocturne",
  );
  const play = page.getByRole("button", {
    name: "Start visual playback preview",
  });
  await play.click();
  await expect(
    page.getByRole("button", { name: "Pause visual playback preview" }),
  ).toHaveAttribute("aria-pressed", "true");
  await page.getByRole("button", { name: "Next illustrative track" }).click();
  await expect(page.locator(".preview-player-credits h3")).toHaveText(
    "Slow Bloom",
  );
  await page
    .getByRole("button", { name: "Like this illustrative track" })
    .click();
  await expect(
    page.getByRole("button", { name: "Like this illustrative track" }),
  ).toHaveAttribute("aria-pressed", "true");
  await page.getByRole("tab", { name: /Keep what moves you/ }).click();
  await expect(page.locator(".preview-library-top")).toHaveText(
    "Your library.",
  );
  await tab.click();
  await expect(page.locator(".preview-player-credits h3")).toHaveText(
    "Slow Bloom",
  );
  await expect(
    page.getByRole("button", { name: "Like this illustrative track" }),
  ).toHaveAttribute("aria-pressed", "true");
  await expect(page.locator("audio, video")).toHaveCount(0);
});

test("keyboard tabs and native FAQ details work", async ({ page }) => {
  await openSite(page);
  const first = page.getByRole("tab", { name: /A new obsession awaits/ });
  await first.focus();
  await page.keyboard.press("ArrowDown");
  await expect(
    page.getByRole("tab", { name: /Give the song its space/ }),
  ).toBeFocused();
  await page.keyboard.press("End");
  await expect(
    page.getByRole("tab", { name: /Keep what moves you/ }),
  ).toHaveAttribute("aria-selected", "true");
  const question = page
    .locator("summary")
    .filter({ hasText: "What can I download here?" });
  await question.click();
  await expect(
    page.getByText(
      "The download below is the complete 0.1.1 Android Studio source project.",
    ),
  ).toBeVisible();
});

test("reduced motion skips intro, persists and never hides the core page", async ({
  page,
}) => {
  await openSite(page);
  await expect(page.locator("html")).toHaveAttribute("data-motion", "reduced");
  await expect(page.locator("#intro")).toBeHidden();
  await page.getByRole("button", { name: "Enable website motion" }).click();
  await expect(page.locator("html")).toHaveAttribute("data-motion", "full");
  await page.getByRole("button", { name: "Reduce website motion" }).click();
  await page.reload();
  await expect(page.locator("html")).toHaveAttribute("data-motion", "reduced");
  await expect(page.getByRole("heading", { name: /Meet your/ })).toBeVisible();
});

test("full motion intro settles and does not replay within the session", async ({
  page,
}) => {
  await openSite(page, false);
  await expect(page.locator("#intro")).toBeHidden({ timeout: 4000 });
  await page.reload();
  await expect(page.locator("#intro")).toBeHidden();
  await expect(page.locator("html")).toHaveAttribute("data-motion", "full");
});

test("mobile navigation opens, closes on Escape and closes after anchor selection", async ({
  page,
}, testInfo) => {
  test.skip(
    !testInfo.project.name.startsWith("mobile"),
    "Mobile navigation only.",
  );
  await openSite(page);
  const toggle = page.getByRole("button", { name: "Open navigation" });
  await toggle.click();
  await expect(page.locator("#mobile-nav")).toBeVisible();
  await expect(page.locator("#mobile-nav a").first()).toBeFocused();
  await page.keyboard.press("Escape");
  await expect(page.locator("#mobile-nav")).toBeHidden();
  await expect(toggle).toBeFocused();
  await toggle.click();
  await page
    .getByRole("navigation", { name: "Mobile navigation" })
    .getByRole("link", { name: /Get Veyra/ })
    .click();
  await expect(page.locator("#mobile-nav")).toBeHidden();
  expect(
    await page.evaluate(() => document.body.classList.contains("menu-open")),
  ).toBe(false);
});

test("all key viewport widths avoid horizontal scrolling", async ({ page }) => {
  await openSite(page);
  for (const width of [320, 360, 390, 768, 1024, 1440, 1920]) {
    await page.setViewportSize({ width, height: 900 });
    const layout = await page.evaluate(() => ({
      document: document.documentElement.scrollWidth,
      viewport: document.documentElement.clientWidth,
    }));
    expect(layout.document, `overflow at ${width}px`).toBeLessThanOrEqual(
      layout.viewport + 1,
    );
  }
});

test("privacy and credits are real production pages", async ({ page }) => {
  await openSite(page);
  await page.getByRole("link", { name: "Website privacy" }).click();
  await expect(page).toHaveURL(/privacy\.html$/);
  await expect(page.getByRole("heading", { level: 1 })).toContainText(
    "A quieter corner",
  );
  await page.getByRole("link", { name: "Credits & licences" }).click();
  await expect(page.getByRole("heading", { level: 1 })).toContainText(
    "Made of music",
  );
  await expect(
    page.getByRole("link", { name: "Read the included Manrope licence" }),
  ).toHaveAttribute("href", "./fonts/Manrope-OFL.txt");
});

test("landing page and interactive player meet automated WCAG A/AA checks", async ({
  page,
}) => {
  await openSite(page);
  await page.evaluate(() =>
    document
      .querySelectorAll(".reveal")
      .forEach((element) => element.classList.add("is-visible")),
  );
  let result = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
    .analyze();
  expect(result.violations).toEqual([]);
  await page.getByRole("tab", { name: /Give the song its space/ }).click();
  result = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
    .analyze();
  expect(result.violations).toEqual([]);
});

test("core content and links remain available without JavaScript", async ({
  browser,
}) => {
  const context = await browser.newContext({
    javaScriptEnabled: false,
    viewport: { width: 390, height: 844 },
  });
  const page = await context.newPage();
  await page.goto("http://127.0.0.1:4173/");
  await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
  await expect(
    page.getByRole("link", { name: "Download source ZIP" }),
  ).toBeVisible();
  await expect(page.locator(".noscript-notice")).toBeVisible();
  await context.close();
});

test("supporting pages stay readable on narrow screens and pass automated accessibility checks", async ({
  page,
}) => {
  for (const route of ["/privacy.html", "/credits.html"]) {
    await page.setViewportSize({ width: 320, height: 844 });
    await page.goto(route);
    expect(
      await page.evaluate(() => document.documentElement.scrollWidth),
    ).toBeLessThanOrEqual(321);
    const result = await new AxeBuilder({ page })
      .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
      .analyze();
    expect(result.violations).toEqual([]);
  }
});

test("section links have unique visible destinations and Get Veyra reaches the download", async ({
  page,
}) => {
  await openSite(page);
  const duplicates = await page.evaluate(() => {
    const ids = [...document.querySelectorAll("[id]")].map(
      (element) => element.id,
    );
    return ids.filter((id, index) => ids.indexOf(id) !== index);
  });
  expect(duplicates).toEqual([]);
  await page.locator(".nav-actions > a").click();
  await expect(page).toHaveURL(/#download$/);
  await expect(page.locator("section#download")).toBeInViewport({
    ratio: 0.25,
  });
});
