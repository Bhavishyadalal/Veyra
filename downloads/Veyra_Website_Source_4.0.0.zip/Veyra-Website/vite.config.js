import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { fileURLToPath } from "node:url";
const page = (name) => fileURLToPath(new URL(name, import.meta.url));
export default defineConfig({
  plugins: [react(), tailwindcss()],
  base: "./",
  resolve: { alias: { "@": page("./src") } },
  build: {
    target: "es2020",
    assetsInlineLimit: 0,
    rollupOptions: {
      input: {
        main: page("index.html"),
        privacy: page("privacy.html"),
        credits: page("credits.html"),
      },
    },
  },
  server: { port: 5173 },
  preview: { port: 4173, strictPort: true },
});
