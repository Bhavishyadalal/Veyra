package app.veyra.music.playback

import android.content.SharedPreferences
import app.veyra.music.data.model.Song
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class PartyPersonalQueueStashTest {

    private lateinit var fakePrefs: FakeSharedPreferences

    @Before
    fun setUp() {
        fakePrefs = FakeSharedPreferences()
        PartyPersonalQueueStash.initForTesting(fakePrefs)
    }

    @Test
    fun testStashAndLoad() {
        assertFalse(PartyPersonalQueueStash.hasStash())
        assertNull(PartyPersonalQueueStash.load())

        val songs = listOf(
            Song(videoId = "vid1", title = "Song 1", artist = "Artist 1", thumbnailUrl = "url1"),
            Song(videoId = "vid2", title = "Song 2", artist = "Artist 2", thumbnailUrl = "url2"),
            Song(videoId = "vid3", title = "Song 3", artist = "Artist 3", thumbnailUrl = "url3"),
        )

        PartyPersonalQueueStash.stash(
            songs = songs,
            index = 1,
            positionMs = 45000L,
            wasPlaying = true,
        )

        assertTrue(PartyPersonalQueueStash.hasStash())
        val snapshot = PartyPersonalQueueStash.load()
        assertNotNull(snapshot)
        assertEquals(3, snapshot!!.songs.size)
        assertEquals("vid1", snapshot.songs[0].videoId)
        assertEquals("vid2", snapshot.songs[1].videoId)
        assertEquals("vid3", snapshot.songs[2].videoId)
        assertEquals(1, snapshot.index)
        assertEquals(45000L, snapshot.positionMs)
        assertTrue(snapshot.wasPlaying)
    }

    @Test
    fun testClearRemovesStash() {
        val songs = listOf(
            Song(videoId = "vid1", title = "Song 1", artist = "Artist 1", thumbnailUrl = null),
        )
        PartyPersonalQueueStash.stash(songs, index = 0, positionMs = 1200L, wasPlaying = false)
        assertTrue(PartyPersonalQueueStash.hasStash())

        PartyPersonalQueueStash.clear()
        assertFalse(PartyPersonalQueueStash.hasStash())
        assertNull(PartyPersonalQueueStash.load())
    }

    @Test
    fun testEmptySongsDoesNotStash() {
        PartyPersonalQueueStash.stash(emptyList(), index = 0, positionMs = 0L, wasPlaying = false)
        assertFalse(PartyPersonalQueueStash.hasStash())
        assertNull(PartyPersonalQueueStash.load())
    }

    @Test
    fun testIndexClamping() {
        val songs = listOf(
            Song(videoId = "vid1", title = "Song 1", artist = "Artist 1", thumbnailUrl = null),
            Song(videoId = "vid2", title = "Song 2", artist = "Artist 2", thumbnailUrl = null),
        )
        PartyPersonalQueueStash.stash(songs, index = 99, positionMs = 0L, wasPlaying = false)
        val snapshot = PartyPersonalQueueStash.load()
        assertNotNull(snapshot)
        assertEquals(1, snapshot!!.index) // Clamped to last index
    }

    @Test
    fun testMidAlbumPartyEntryStashesFullContextAndRestoresOnExit() {
        val albumSongs = List(15) { i ->
            Song(
                videoId = "track-$i",
                title = "Song $i",
                artist = "Artist",
                thumbnailUrl = null,
                albumName = "Album 1",
            )
        }

        // Host was playing track #4 (index 4) with 30s elapsed
        PartyPersonalQueueStash.stash(
            songs = albumSongs,
            index = 4,
            positionMs = 30000L,
            wasPlaying = true,
        )

        // When leaving party, stash should restore all 15 tracks at index 4
        val restored = PartyPersonalQueueStash.load()
        assertNotNull(restored)
        assertEquals(15, restored!!.songs.size)
        assertEquals(4, restored.index)
        assertEquals("track-4", restored.songs[restored.index].videoId)
        assertEquals(30000L, restored.positionMs)
        assertTrue(restored.wasPlaying)

        // Clear after restoring
        PartyPersonalQueueStash.clear()
        assertFalse(PartyPersonalQueueStash.hasStash())
    }

    @Test
    fun testJoinerPersonalQueueStashedAndRestoredOnExit() {
        val joinerPersonalQueue = listOf(
            Song(videoId = "personal-1", title = "P1", artist = "Artist", thumbnailUrl = null),
            Song(videoId = "personal-2", title = "P2", artist = "Artist", thumbnailUrl = null),
        )

        PartyPersonalQueueStash.stash(
            songs = joinerPersonalQueue,
            index = 0,
            positionMs = 15000L,
            wasPlaying = false,
        )

        val restored = PartyPersonalQueueStash.load()
        assertNotNull(restored)
        assertEquals(2, restored!!.songs.size)
        assertEquals("personal-1", restored.songs[0].videoId)
        assertEquals(15000L, restored.positionMs)
        assertFalse(restored.wasPlaying)
    }

    @Test
    fun `entering party keeps local tracks and the original current index`() {
        val ids = listOf("file:///music/one.flac", "online-two", "content://media/audio/3", "online-four")
        val player = fakePlayer(ids, 2)
        assertTrue(PartyPersonalQueueStash.stashFromPlayer(player))
        val restored = PartyPersonalQueueStash.load()!!
        assertEquals(ids, restored.songs.map { it.videoId })
        assertEquals("content://media/audio/3", restored.songs[restored.index].videoId)
        assertEquals(12000L, restored.positionMs)
        assertFalse(restored.wasPlaying)
    }

    @Test
    fun `an entirely local personal queue is still restorable after a party`() {
        val ids = listOf("file:///music/one.flac", "file:///music/two.flac")
        assertTrue(PartyPersonalQueueStash.stashFromPlayer(fakePlayer(ids, 1)))
        assertEquals(ids, PartyPersonalQueueStash.load()!!.songs.map { it.videoId })
    }

    private fun fakePlayer(ids: List<String>, index: Int): androidx.media3.common.Player {
        val items = ids.map { androidx.media3.common.MediaItem.Builder().setMediaId(it).build() }
        return java.lang.reflect.Proxy.newProxyInstance(
            androidx.media3.common.Player::class.java.classLoader,
            arrayOf(androidx.media3.common.Player::class.java),
        ) { _, method, args -> when (method.name) {
            "getMediaItemCount" -> items.size
            "getMediaItemAt" -> items[args!![0] as Int]
            "getCurrentMediaItemIndex" -> index
            "getCurrentPosition" -> 12000L
            "getPlayWhenReady" -> false
            else -> null
        } } as androidx.media3.common.Player
    }

    private class FakeSharedPreferences : SharedPreferences {
        private val data = mutableMapOf<String, Any?>()

        override fun getAll(): Map<String, *> = HashMap(data)
        override fun getString(key: String?, defValue: String?): String? =
            data[key] as? String ?: defValue

        @Suppress("UNCHECKED_CAST")
        override fun getStringSet(key: String?, defValues: Set<String>?): Set<String>? =
            data[key] as? Set<String> ?: defValues

        override fun getInt(key: String?, defValue: Int): Int =
            (data[key] as? Number)?.toInt() ?: defValue

        override fun getLong(key: String?, defValue: Long): Long =
            (data[key] as? Number)?.toLong() ?: defValue

        override fun getFloat(key: String?, defValue: Float): Float =
            (data[key] as? Number)?.toFloat() ?: defValue

        override fun getBoolean(key: String?, defValue: Boolean): Boolean =
            data[key] as? Boolean ?: defValue

        override fun contains(key: String?): Boolean = data.containsKey(key)

        override fun edit(): SharedPreferences.Editor = FakeEditor(this)

        override fun registerOnSharedPreferenceChangeListener(
            listener: SharedPreferences.OnSharedPreferenceChangeListener?,
        ) {}

        override fun unregisterOnSharedPreferenceChangeListener(
            listener: SharedPreferences.OnSharedPreferenceChangeListener?,
        ) {}

        private class FakeEditor(private val prefs: FakeSharedPreferences) : SharedPreferences.Editor {
            private val pending = mutableMapOf<String, Any?>()
            private val removed = mutableSetOf<String>()
            private var clearAll = false

            override fun putString(key: String?, value: String?): SharedPreferences.Editor {
                if (key != null) pending[key] = value
                return this
            }

            override fun putStringSet(key: String?, values: Set<String>?): SharedPreferences.Editor {
                if (key != null) pending[key] = values
                return this
            }

            override fun putInt(key: String?, value: Int): SharedPreferences.Editor {
                if (key != null) pending[key] = value
                return this
            }

            override fun putLong(key: String?, value: Long): SharedPreferences.Editor {
                if (key != null) pending[key] = value
                return this
            }

            override fun putFloat(key: String?, value: Float): SharedPreferences.Editor {
                if (key != null) pending[key] = value
                return this
            }

            override fun putBoolean(key: String?, value: Boolean): SharedPreferences.Editor {
                if (key != null) pending[key] = value
                return this
            }

            override fun remove(key: String?): SharedPreferences.Editor {
                if (key != null) removed.add(key)
                return this
            }

            override fun clear(): SharedPreferences.Editor {
                clearAll = true
                return this
            }

            override fun commit(): Boolean {
                apply()
                return true
            }

            override fun apply() {
                if (clearAll) {
                    prefs.data.clear()
                }
                for (key in removed) {
                    prefs.data.remove(key)
                }
                prefs.data.putAll(pending)
            }
        }
    }
}
